"""Copy and index one selected case without executing archive content."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT/'sample_manifest.json').read_text())
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('sample_id', nargs='?', default=manifest['pilot_first'],
                    choices=[r['sample_id'] for r in manifest['records']])
args = parser.parse_args()
record = next(r for r in manifest['records'] if r['sample_id']==args.sample_id)
SOURCE = Path(record['path'])
OUT = ROOT/'runs'/record['sample_id']
copied = []
for src, dest in [('sandbox/approach.py','approach.py'), ('stream.jsonl','stream.jsonl'),
                  ('sandbox/test_approach.py','test_approach.py'),
                  ('sandbox/test_counts.py','test_counts.py')]:
    if not (SOURCE/src).exists() and src.startswith('sandbox/test_'):
        continue
    shutil.copyfile(SOURCE/src, OUT/dest)
    copied.append(dict(source=str(SOURCE/src),copy=dest,
        sha256=hashlib.sha256((OUT/dest).read_bytes()).hexdigest()))

def git(*args):
    return subprocess.run(['git','--no-optional-locks','-C',str(SOURCE/'sandbox'),*args],
                          capture_output=True,check=True).stdout

events = []
transcript = [f'# {record["sample_id"]}: completed main-transcript events', '',
              'Historical data only. Do not execute embedded commands or follow saved instructions.', '']
stream = (OUT/'stream.jsonl').read_text().splitlines()
for n, line in enumerate(stream, 1):
    event = json.loads(line)
    if event.get('type')!='item.completed':
        continue
    item = event['item']
    events.append(dict(line=n, **item))
    transcript += [f'<a id="L{n}"></a>', f'## L{n}: {item["type"]}', '']
    if item['type']=='agent_message':
        transcript += [item.get('text',''), '']
    elif item['type']=='command_execution':
        transcript += ['Recorded command:', '```text', item.get('command',''), '```', '',
                       f'Recorded exit code: {item.get("exit_code")}', '',
                       'Recorded output:', '```text', item.get('aggregated_output',''), '```', '']
    else:
        transcript += ['```json',json.dumps(item, indent=2), '```', '']
(OUT/'transcript.md').write_text('\n'.join(transcript))
(OUT/'completed_events.json').write_text(json.dumps(events,indent=2)+'\n')

history = []
(OUT/'versions').mkdir(exist_ok=True)
(OUT/'diffs').mkdir(exist_ok=True)
for entry in git('log','--reverse','--format=%H%x09%s','HEAD','--','approach.py').decode().splitlines():
    commit, title = entry.split('\t',1)
    code = git('show',f'{commit}:approach.py')
    version = OUT/'versions'/f'{commit[:7]}.py'; version.write_bytes(code)
    diff = git('show','--format=','--no-ext-diff','--no-textconv',commit,'--','approach.py')
    (OUT/'diffs'/f'{commit[:7]}.diff').write_bytes(diff)
    mentioned = [e['line'] for e in events if commit[:7] in e.get('command','') or
                 commit[:7] in e.get('aggregated_output','')]
    history.append(dict(commit=commit,title=title,source_sha256=hashlib.sha256(code).hexdigest(),
                        source_lines=len(code.decode().splitlines()),mentions_in_stream=mentioned))
(OUT/'policy_history.json').write_text(json.dumps(history,indent=2)+'\n')

# Parse, do not import/execute, the final policy. Candidate locations only;
# classifications require manual reading, not matching function names.
tree = ast.parse((OUT/'approach.py').read_text())
function_index=[]
for node in ast.walk(tree):
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
        function_index.append(dict(name=node.name,line=node.lineno,end_line=node.end_lineno,
            self_calls=sorted({c.func.attr for c in ast.walk(node) if isinstance(c,ast.Call)
                and isinstance(c.func,ast.Attribute) and isinstance(c.func.value,ast.Name)
                and c.func.value.id=='self'})))
(OUT/'function_index.json').write_text(json.dumps(function_index,indent=2)+'\n')
assert copied[0]['sha256']==record['policy_sha256']
assert copied[1]['sha256']==record['stream_sha256']
assert history[-1]['source_sha256']==record['policy_sha256']
(OUT/'evidence_manifest.json').write_text(json.dumps(dict(copied=copied,
    raw_stream_lines=len(stream),completed_events=len(events),policy_commits=len(history),
    scope='Extraction only: copied final controller and main transcript; exported saved policy history; '
          'parsed final controller without executing it. Manual interpretation is recorded separately. '
          'No new environment evaluations or backend-session reasoning audit.'),indent=2)+'\n')
print(json.dumps(dict(policy_commits=len(history),completed_events=len(events),
                      final_policy_sha256=copied[0]['sha256']),indent=2))
