"""Inventory archived runs without reading outcome scores or executing saved code.

Uses macOS system Ruby/Psych for safe YAML parsing (no extra installation).
Writes only alongside this script. No policies, commands, or prompts are executed.
"""
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

OUT = Path(__file__).resolve().parent
ARCHIVE = Path('/Users/zahra.bashir/.cache/robocode-results-viewer/1sNuRoRxMxh7_VDE93hWn_ZNHBd74Uzt2/runs')
ENVIRONMENTS = {'obstruction3d_generalized': 'kinematic3d',
                'dynpusht2d': 'dynamic2d', 'rovers_generalized': 'pddlstream'}
SEEDS = [424, 24]  # Reference replicate, then the lowest other available seed.

def sha(path):
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

configs, unpaired = [], []
for directory, dirs, files in os.walk(ARCHIVE):
    dirs[:] = [d for d in dirs if d not in {'sandbox', '.git', '.hydra', 'videos', 'mcp_renders'}]
    p = Path(directory)
    if 'results.json' in files:
        if (p / '.hydra/config.yaml').is_file():
            configs.append(p / '.hydra/config.yaml')
        else:
            unpaired.append(str(p.relative_to(ARCHIVE)))
configs.sort()
ruby = '''paths = JSON.parse(STDIN.read); puts JSON.generate(paths.map { |p|
  begin
    {"path" => p, "config" => YAML.safe_load(File.read(p), [], [], true)}
  rescue => e
    {"path" => p, "error" => e.message}
  end
})'''
decoded = json.loads(subprocess.run(['/usr/bin/ruby', '-rjson', '-ryaml', '-e', ruby],
                     input=json.dumps([str(p) for p in configs]), text=True,
                     capture_output=True, check=True).stdout)
errors = [r for r in decoded if 'error' in r]
assert not errors, errors
records = []
for row in decoded:
    config = row['config']; p = Path(row['path']).parent.parent
    rel = p.relative_to(ARCHIVE); app = config.get('approach', {})
    app = app if isinstance(app, dict) else {}
    backend = app.get('backend', {}); backend = backend if isinstance(backend, dict) else {}
    prov = p / 'provenance.json'
    records.append(dict(path=str(p), relative_path=str(rel), condition=rel.parts[0],
        experiment_id=config.get('experiment_id'), replicate_seed=config.get('replicate_seed'),
        model=backend.get('model'), reasoning_effort=backend.get('reasoning_effort'),
        max_budget_usd=app.get('max_budget_usd'), load_dir=app.get('load_dir'),
        blackbox=app.get('blackbox'), blackbox_strict=app.get('blackbox_strict'),
        primitive_level=config.get('primitive_level'), environment=config.get('environment'),
        config=config, config_sha256=sha(Path(row['path'])),
        provenance=json.loads(prov.read_text()) if prov.is_file() else None,
        artifacts={name:(p/name).exists() for name in ['stream.jsonl','env_description.md',
                   'sandbox/approach.py','sandbox/.git','sandbox/.agent_sessions']}))

matched = [r for r in records if r['condition']=='Blackbox' and r['model']=='gpt-5.6-sol'
           and r['blackbox'] is True and r['blackbox_strict'] is True
           and r['primitive_level']=='none' and r['load_dir'] is None]
selected = []
for env, family in ENVIRONMENTS.items():
    for seed in SEEDS:
        candidates = [r for r in matched if (r['experiment_id'] or '').split('__')[0]==env
                      and r['replicate_seed']==seed
                      and f'/Codex GPT5.6 Sol/{family}/' in r['path']]
        assert len(candidates)==1, (env, seed, [r['path'] for r in candidates])
        r = dict(candidates[0]); r['sample_id'] = f'{env}_replicate_{seed}'
        assert r['max_budget_usd']==20.0 and r['reasoning_effort']=='medium'
        selected.append(r)

# Fingerprint related records even outside the selected batch. Identical code alone
# never collapses two runs. Keep exact duplicate candidates explicit for review.
related = [r for r in records if (r['experiment_id'] or '').split('__')[0] in ENVIRONMENTS
           and r['model']=='gpt-5.6-sol']
for r in related:
    p = Path(r['path'])
    r['stream_sha256'] = sha(p/'stream.jsonl')
    r['policy_sha256'] = sha(p/'sandbox/approach.py')
    r['thread_ids'] = []
    if r['stream_sha256']:
        for line in (p/'stream.jsonl').read_text().splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if event.get('type')=='thread.started':
                value = event.get('thread_id')
                if value and value not in r['thread_ids']:
                    r['thread_ids'].append(value)
lookup = {r['path']:r for r in related}
for s in selected:
    r = lookup[s['path']]
    s.update({k:r[k] for k in ['stream_sha256','policy_sha256','thread_ids']})
    p = Path(s['path']); dest = OUT/'runs'/s['sample_id']; dest.mkdir(parents=True, exist_ok=True)
    for src, name in [('.hydra/config.yaml','config.yaml'),('env_description.md','task.md'),
                       ('provenance.json','provenance.json')]:
        if (p/src).is_file():
            shutil.copyfile(p/src, dest/name)
    # Read-only Git commands; no checkout or execution of historical content.
    def git(*args):
        return subprocess.run(['git','--no-optional-locks','-C',str(p/'sandbox'),*args],
                              capture_output=True,text=True,check=True).stdout.strip()
    s['git_head'] = git('rev-parse','HEAD')
    head = subprocess.run(['git','--no-optional-locks','-C',str(p/'sandbox'),
                           'show','HEAD:approach.py'],capture_output=True,check=True).stdout
    s['working_policy_matches_head'] = hashlib.sha256(head).hexdigest()==s['policy_sha256']
    s['saved_policy_commits'] = int(git('rev-list','--count','HEAD','--','approach.py'))

groups = defaultdict(list)
for r in related:
    if r['stream_sha256'] and r['policy_sha256']:
        groups[(r['stream_sha256'],r['policy_sha256'])].append(r['relative_path'])
duplicates = [paths for paths in groups.values() if len(paths)>1]
write('inventory.json', dict(archive=str(ARCHIVE), paired_configs=len(records),
    counts_by_top_folder=dict(Counter(r['condition'] for r in records)),
    results_without_config=unpaired, records=records))
write('identity_audit.json',dict(scope='Same three environments and same model across all top folders',
    related_records=related, exact_transcript_and_policy_groups=duplicates,
    note='Groups are duplicate candidates, not independent development runs. '
         'Reevaluations identified by load_dir/provenance are not new generations. '
         'Different transcripts remain distinct even with matching policy code. '
         'No results.json contents were read.'))
write('sample_manifest.json', dict(selection='Task-structure diversity; fixed seeds 424 and 24; '
    'original Blackbox family paths; same model, effort, budget, access, and primitive setting. '
    'No outcome-score or code-content selection.',
    pilot_first='rovers_generalized_replicate_424', records=selected))
print(json.dumps(dict(paired_configs=len(records), counts=dict(Counter(r['condition'] for r in records)),
    related_records=len(related), duplicate_candidate_groups=len(duplicates),
    selected=[{k:r[k] for k in ['sample_id','saved_policy_commits','working_policy_matches_head']} for r in selected]),indent=2))
