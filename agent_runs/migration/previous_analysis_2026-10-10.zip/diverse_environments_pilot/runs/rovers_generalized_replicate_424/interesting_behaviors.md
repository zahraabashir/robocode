# Interesting development choices in Rovers 424

Scope: one archived run, not both selected Rovers replicates. Sources are the copied main transcript, saved policy diffs, and final controller. No new evaluations were run. Arrow sequences describe recorded order, not proof of hidden causation.

## What generalizes from Obstruction2D?

Phase decomposition appears in both inspected controllers. Absence of explicit multi-step search does not: Rovers 424 includes A*-style navigation in its first saved policy and final policy. This is a concrete counterexample to an all-environments claim, not an estimate of prevalence. Its task-level sample/images/send/drop/home sequence remains programmed rather than searched.

## 1. A planned route can fail because execution changes its direction

**Compute a route judged clear by the model → encounter collisions → diagnose motion deviating from the planned segment → preserve the segment direction in the action command.**

At [L54](transcript.md#L54), the agent attributes an important navigation failure to separately clipping x and y movement. The [6a2200f diff](diffs/6a2200f.diff) replaces independent clipping with one scale factor. As a mathematical illustration, a requested vector (0.4, 0.1) independently clipped to 0.2 becomes (0.2, 0.1), which changes direction; shared scaling produces (0.2, 0.05), which preserves direction. These illustrative numbers are not an archived action.

Interesting question: when predictions fail, does the agent change the world model, the planned route, or the mechanism that executes the route? Here the visible diagnosis and edit target execution. The correction does not prove the geometry model itself is universally accurate.

## 2. It turns a troublesome parameter tradeoff into a conditional strategy

**Large obstacle clearance blocks narrow routes → smaller clearance risks collisions → search with the larger margin first → retry with a smaller margin only if no route is found.**

[L87](transcript.md#L87) states the tradeoff. [bc97ce1](diffs/bc97ce1.diff) introduces a two-margin planner, initially using 0.20 and 0.185. The final [approach.py](approach.py), lines 127–131, uses 0.21 and 0.195 after further tuning.

This is a structural change from choosing one global margin to conditioning the margin on a search result. No probability of model correctness or expected utility is computed, so it should not automatically be called Bayesian or resource-rational planning.

Interesting question: when does the agent replace a single tuned rule with a conditional fallback?

## 3. It abandons an apparently better search objective after testing

**Reason that diagonal and axial motion each cost one action → change grid costs and heuristic → test → restore the earlier geometric search costs.**

[L250](transcript.md#L250) announces the optimization. [4e995ed](diffs/4e995ed.diff) changes diagonal cost from 1.414 to 1 and switches to a Chebyshev heuristic; it also adds sampling on arrival. [0d4421d](diffs/0d4421d.diff) reverses only the search-cost change, preserving arrival sampling. The three matched ordinary seeds at [L254](transcript.md#L254) versus [L258](transcript.md#L258) finish in 65/56/31 versus 64/54/31 steps; all pass. [L265](transcript.md#L265) describes keeping the empirically shorter planner.

The observed difference is small and from three cases. It does not show that the restored objective is generally better or isolate why smoothing and continuous execution change route efficiency. It does show selective rollback rather than wholesale rejection of both changes.

Interesting question: what evidence makes the agent abandon an appealing model-based optimization, and which parts does it preserve?

## 4. It investigates conflicting evidence before editing the policy

**Many numerical tests pass → visualization appears suspicious → rerun the same seed and object count numerically → observe success.**

[L228](transcript.md#L228) renders seed 42 with four objectives. At [L237](transcript.md#L237), the agent explicitly says it will treat the suspicious visual case as a failure until checked. [L239](transcript.md#L239) runs pinned counts 1–4 for seed 42; the four-objective case succeeds in 58 steps. No policy edit occurs between L237 and this check. At [L250](transcript.md#L250), the agent attributes the visual concern to frames covering only an early part of the trajectory.

Supported: an exact-case numerical check before editing, and a successful rerun. The explanation about the visualization is the agent's recorded attribution; this analysis has not independently reconstructed the removed rendered frames.

Interesting question: does the agent distinguish a policy failure from incomplete or misleading observations, and how does it choose the follow-up measurement?

## Additional controller behavior worth testing

If both clearance-based searches fail, the final `_plan` returns the goal directly. The robot can therefore attempt direct movement even when the model found no route. This is an implemented fallback, not evidence that it occurred in any particular final evaluation. Measuring its actual use would require an instrumented replay. It is another reason to describe this controller as a combination of planning and fallback rules.

## A research question that spans both environments

**When observed behavior disagrees with expectations, what does the coding agent revise: its model of the environment, its plan, its execution code, or its way of gathering evidence?**

The four sequences above offer candidate examples, not exhaustive labels or causal results. The initial implementation of A* means this run is especially useful for comparing model/plan/execution failures with Obstruction2D's predominantly heuristic repairs.
