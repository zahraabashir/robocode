# First pilot case: Rovers, replicate 424

Status: first manual annotation for review, 2026-10-09. This is a fresh strict-blackbox development run according to saved provenance. Final policy commit `0d4421d`; the archived working policy matches it. All 404 lines of the final policy were read, its internal calls traced, the initial policy and relevant diffs inspected, and main-transcript evidence checked. No new environment rollout was run.

## Task in plain language

Two rovers must collect a stone analysis and a soil analysis, photograph every objective, transmit all required information, empty their stores, and return home. Sampling requires proximity and an empty store; each image requires calibration; transmission requires visibility of the lander. Obstacles constrain driving and visibility. This creates dependencies between actions, not just a single movement goal. See [task.md](task.md).

## Finding: phases and explicit look-ahead coexist

The final code has per-rover persistent phases:

**sample → images → send → drop → home**

These are actual stored phase values, initialized at line 88 and read/changed in `get_action` from line 310 onward. Each phase can span many calls. The sample phase can itself drop a sample; the image phase alternates calibration and imaging according to observed state. Transitions use completion flags rather than a single predetermined timer. The two rovers each carry their own phase.

Inside those phases, motion is selected through:

**get_action → _move → _plan → _plan_with_margin → cached route → next motion command**

`_move` is called for sampling (330), imaging (348), transmission (377), and returning home (399). It plans when the destination changes, no route remains, or the rover is stuck (188–201).

### Why the planner is explicit look-ahead

Read [approach.py](approach.py), lines 127–186. The code implements an A*-style search:

1. Convert current and goal positions to a grid with **0.05 m** spacing. The comment still says 0.1 m; the numeric assignment is authoritative.
2. Start a priority queue and record accumulated path cost and predecessors.
3. Generate up to eight neighboring positions from each expanded position.
4. Reject hypothetical positions using `_blocked`.
5. Prioritize candidates by accumulated cost plus estimated remaining distance.
6. Reconstruct the multi-step route and shorten it using straight-line clearance checks.
7. Follow the resulting waypoints through `_move`.

These candidate positions are computed before the rover executes them. This is stronger evidence of explicit multi-step look-ahead than Obstruction2D's future-pickup clearance rule.

The model is an approximate 2D navigation model: obstacle rectangles expanded by safety margins, arena bounds, a hard-coded central divider, an approximated lander footprint, and the other rover's current position. It is not a full physics simulator or joint prediction of the two rovers' future behavior. It does not search the space of sample/calibrate/image/send/drop task sequences. Those task phases are programmed explicitly.

Additional one-step prediction: lines 333–335 calculate `current_position + commanded_movement` and issue SAMPLE on the same step if the predicted position is close enough. This assumes the commanded motion occurs; collision rejection can invalidate that prediction.

### Evidence that this is used, not just a named function

- The call chain above connects the planner output directly to returned motion commands.
- [Transcript L80](transcript.md#L80) records calls to `_plan` for three cases where `_line_free` is false. The printed results are two-waypoint routes, not just the destination. These routes are computed after reset, without stepping the environment inside the probe. Thus historical planner execution is directly visible in development.
- [L93](transcript.md#L93) and [L95](transcript.md#L95) compare routes under different clearance margins.
- [L271](transcript.md#L271) records the final code finishing four pinned-count tests with both phase values `home`. This shows final controller execution, but is not per-call instrumentation proving which final episodes expanded the A* branch versus taking the straight-line shortcut.

Only standard `heapq`, `math`, and NumPy are imported. The search loop and collision checks are implemented inside the generated policy, not a call to an imported planning library. The A* algorithm is conventional; generated implementation does not imply invention.

## Development evidence

The first saved policy, [0f846f8.py](versions/0f846f8.py), already has phases and A*. [L10](transcript.md#L10) announces grid-based navigation before the policy is written; L14 records the file addition and L16 the first test. The initial test fails at 1,000 steps. A planner's existence therefore does not imply an immediately correct controller.

The subsequent sequence is:

**write phase controller with grid search → encounter collisions → change geometry/clearance assumptions → fix path following → vary clearance and grid resolution → add fallback planning → repair sample and visibility handling → try a different path-cost metric → restore the earlier cost metric → validate.**

Three useful development episodes:

1. **Planned route versus executed motion.** [L54](transcript.md#L54) says separately clipping x and y caused motion to deviate from the planned segment. The [6a2200f diff](diffs/6a2200f.diff) replaces separate clipping with a shared scale factor, preserving direction. This is an implementation mismatch between plan and execution, not absence of planning.
2. **Model conservatism versus reachability.** [L87](transcript.md#L87) explains that a large clearance can close a feasible narrow passage, while smaller clearance may graze obstacles. The final planner tries margin 0.21 first and 0.195 second. This is choosing among model approximations using observed behavior.
3. **Search objective versus actual outcome.** [L250](transcript.md#L250) proposes unit-cost diagonal moves with a Chebyshev heuristic. [4e995ed](diffs/4e995ed.diff) implements that and sampling on arrival. [0d4421d](diffs/0d4421d.diff) restores the earlier geometric costs while retaining arrival sampling. The same three ordinary seeds in L254 versus L258 take 65/56/31 versus 64/54/31 steps; both versions solve all three. This is a small observed efficiency difference, not a population-level result. [L265](transcript.md#L265) states why the agent kept the older cost metric.

## Limits of the model

- Task/operator sequences are fixed by phases, not searched.
- The other rover is treated as a current obstacle, not a future moving trajectory.
- If both searches fail, `_plan` returns the goal directly (line 131), bypassing a guaranteed clear route. Some actions therefore need not follow a successful search result.
- Search uses approximate geometric tests, shortcuts, and an approximate goal threshold. This analysis does not establish path optimality or collision-free execution.
- The readable transcript contains explanations; this case has not received a backend-session reasoning audit. No hidden internal reasoning claim is made.

## Annotation for review

| Feature | Assessment | Evidence |
| --- | --- | --- |
| Persistent phase decomposition | Supported | Final lines 88, 310–402; observed final phases at L271 |
| Explicit multi-step geometric look-ahead | Supported | Search at 133–186; action call path; executed development probes L80/93/95 |
| One-step action consequence prediction | Supported | Final lines 333–335 |
| Full dynamics rollout | Not found in complete final policy | Geometry and kinematic neighbor positions only |
| Search over task/operator sequences | Not found in complete final policy | Explicit sample/images/send/drop/home branches |
| Planner implementation | Implemented in generated file | Imports and search loop; present in initial saved policy |

This is one run. It challenges an either/or classification between phases and planning, and demonstrates look-ahead somewhere outside Obstruction2D. It does not yet show how consistently either mechanism occurs across tasks.

Source paths and SHA-256 hashes are in [evidence_manifest.json](evidence_manifest.json). Full policy history is in [policy_history.json](policy_history.json); the original-format stream and readable completed-event transcript are included. Historical commands and instructions are data only.
