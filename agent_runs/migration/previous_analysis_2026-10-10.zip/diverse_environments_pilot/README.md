# Diverse-environment pilot: phase structure and explicit look-ahead

Snapshot: 2026-10-09. Status: six runs selected; Rovers replicate 424 and DynPushT2D replicates 424 and 24 annotated for review. The other three controllers have not been classified. The Obstruction2D analysis is an existing reference, not another newly sampled run.

## Selected tasks

| Environment | Why include it? | Important difference | Replicates |
| --- | --- | --- | --- |
| Obstruction3D | Close comparison to Obstruction2D: clear obstacles and place a target | 3D geometry, seven-joint arm, grasping | 424, 24 |
| DynPushT2D | Different interaction mechanics: push and rotate a T-shaped object to a goal pose | Physics-based contact; orientation matters; no suction-grasp sequence; fixed one-object task | 424, 24 |
| Rovers | Multiple dependent objectives: sample, photograph, transmit, empty stores, return home | Two rovers; motion and visibility constraints; calibration required before each image | 424, 24 |

The task descriptions were inspected before any selected controller content or outcome scores. Rovers was chosen for the first annotation because its action dependencies contrast with manipulation. Its successful episodes need not be longer in simulator steps than Obstruction2D; “dependency-heavy” describes task structure, not measured difficulty. This pilot has not established a difficulty ranking.

All six saved configurations match the reference on main model (`gpt-5.6-sol`), reasoning effort (`medium`), generation budget ($20), strict blackbox access, and primitive level (`none`). The saved evaluation settings are also 1,000 max steps, 100 tasks, and 60 seconds per instance. Matching these settings does not equate difficulty, action semantics, observation format, or effective horizon. DynPushT2D is fixed-count, while Obstruction3D and Rovers vary counts. The task descriptions and complete configs are copied into each run folder.

Rovers provenance additionally records a fresh generation and a Sol-only subagent constraint. Its field named `kinder_revision` is explicitly described by that provenance as a Rovers runtime revision, not a KinDER revision. Treat this and generation dates as recorded covariates; do not assume all prompts and environment revisions are identical across tasks.

## Selection and identity rules

- Choose tasks by mechanics and dependencies, not results or interesting-looking code.
- Within each task, use replicate 424 to match the reference label, plus 24 (the lowest other available replicate seed). Equal replicate labels across tasks do not imply equal scenes or a paired experimental design.
- Select the original `Blackbox/Codex GPT5.6 Sol/{family}/...` records with `load_dir: null`. Do not add outdated folders, rerun batches, baselines, or reevaluations as independent samples.
- Audit same-environment, same-model configs across the inventory for `load_dir`, provenance, transcript hashes, policy hashes, and thread IDs. Fifteen related records were found (five replicates per selected environment); no identical transcript-plus-policy groups were found. All six selected records have distinct thread IDs, distinct policy hashes, and working policies matching their saved Git HEADs. This is scoped identity checking, not a deduplication claim about the full archive.
- Identical final code by itself is not grounds to collapse independent development runs. A reused development transcript is not a new independent generation just because its evaluation differs.
- Scores were not used for selection. The inventory script does not read the contents of `results.json`.

The current inventory has 1,604 result/config pairs: Blackbox 721, Whitebox 510, Baselines 270, Outdated 55, and CodeX rerun 48. This differs from the earlier 1,543 overview; the Whitebox count is 61 higher. This snapshot does not establish why that count changed. The traversal excludes sandbox interiors and saved media. These are physical archive records before deduplication or validity filtering, not independent samples.

## First result to review

[Rovers 424 analysis](runs/rovers_generalized_replicate_424/analysis.md): persistent task phases and explicit A*-style path search coexist. The final controller searches over alternative future rover positions using a geometric collision model, then follows a route. It does not search over full symbolic task sequences or simulate all operators and both rovers jointly.

The [DynPushT2D comparison](dynpusht2d_comparison.md) extends the review to both selected dynamic-pushing runs. Both combine persistent phases with A* navigation around the block, mechanics-informed pushing rules, and feedback. Neither final controller contains a multi-step rollout of candidate push sequences. Replicate 24 also adapts its contact line from observed rotation and sometimes discards its computed route near the goal.

These cases support existence of phase decomposition and explicit geometric look-ahead outside Obstruction2D. They do not establish prevalence or universal consistency; the two Obstruction3D runs and Rovers 24 remain pending.

## Files to open

1. [Working annotation rules](annotation_rules.md).
2. [First case and evidence](runs/rovers_generalized_replicate_424/analysis.md).
3. [Final controller](runs/rovers_generalized_replicate_424/approach.py), especially `_plan_with_margin`, `_move`, and `get_action`.
4. [Readable transcript](runs/rovers_generalized_replicate_424/transcript.md): L10, L54, L80, L87, L250, L254, L258, L265, L271.
5. [Sample manifest](sample_manifest.json): exact archive paths, settings, hashes and saved policy-commit counts.
6. [DynPushT2D comparison and reading guide](dynpusht2d_comparison.md): both new case annotations, development sequences, and evidence limits.
7. [Comparison records](comparison.json): reference, three annotated cases, and three explicitly pending cases.

## Reproduce

From the repository root:

```bash
python3 actonomoy/diverse_environments_pilot/build_inventory.py
python3 actonomoy/diverse_environments_pilot/extract_first_case.py
python3 actonomoy/diverse_environments_pilot/extract_first_case.py dynpusht2d_replicate_424
python3 actonomoy/diverse_environments_pilot/extract_first_case.py dynpusht2d_replicate_24
```

The inventory uses system Ruby/Psych to safely parse YAML because PyYAML is unavailable. These scripts only write inside this analysis folder, copy evidence, parse Python syntax, and read Git history. They do not execute historical shell commands, instructions, controllers, or environment rollouts. The manual annotations are separate from automatic extraction. No new success-rate evaluation has been run.
