# DynPushT2D: where does the controller actually plan?

Both selected runs combine **explicit geometric route planning, phase rules, and feedback control**. Neither final controller contains a multi-step simulation of how candidate pushes would move and rotate the block. Calling the whole controller either “model-free” or “model-based” hides this distinction.

Archive analysis completed 2026-10-09. No new physics evaluations were run. These are the two previously selected strict-blackbox GPT-5.6-sol runs, replicates 424 and 24; they were not selected for these findings.

## The task in one sentence

A small circular robot must push a T-shaped block until its position and orientation match a target. It can move in x and y; it cannot grasp the block. See the copied [task description](runs/dynpusht2d_replicate_424/task.md).

## Answer to the classification question

| Mechanism | Replicate 424 | Replicate 24 |
| --- | --- | --- |
| Persistent phases | Yes: navigate, paired rotation pushes, translate, retreat | Yes: choose, approach, contact, push, retreat |
| Explicit multi-step look-ahead | Yes: A* searches possible routes for the pusher | Yes: A* searches possible routes for the pusher |
| World representation used in that search | T geometry and arena limits, holding the current block pose fixed | Approximate T geometry and arena limits, holding the current block pose fixed |
| Choosing pushes | Calculated centroid/contact lines, paired rotation strokes, thresholds | Estimated center of mass, contact-side selection, thresholds |
| Reacting to observed outcomes | Stops strokes using measured rotation or displacement; detects navigation stalls | Replans after the block moves; adjusts contact offset from observed rotation |
| Simulating alternative sequences of pushes before execution | Not found in the complete final controller | Not found in the complete final controller |
| Model-free reinforcement learning | No learned value function or reward-trained policy found | No learned value function or reward-trained policy found |

The useful label is **a phase controller with model-based geometric navigation and mechanics-informed pushing heuristics**. “Heuristic” and “model-based” can coexist: an approximate model can inform a rule, and A* itself uses a heuristic to guide explicit search. Neither finding demonstrates the coding agent's private reasoning process.

An example of the distinction:

> “To reach the other side of the T, compare routes around its edges before moving.” → implemented geometric look-ahead.
>
> “Predict the block's position and angle after push A, then after push B; compare that sequence with C then D.” → not found in these final programs.
>
> “Push a little, observe that the block rotated, shift the contact point.” → implemented feedback/adaptation in replicate 24; this alone is not a forward dynamics model.

## Three development sequences worth inspecting

**1. Replicate 424 genuinely replaces its controller architecture.**

Reactive orbit-and-push code → agent reports learning that the reported pose is not the center of mass → deletes and re-adds `approach.py` → commits a controller with A*, paired rotation pushes, and centroid-based translation → tests it.

The readable explanation is [transcript L43](runs/dynpusht2d_replicate_424/transcript.md#L43); deletion/addition are L45/L47; the substantial replacement is [commit 2fc7f82](runs/dynpusht2d_replicate_424/diffs/2fc7f82.diff), recorded at L49. The preceding controller is [ab58679](runs/dynpusht2d_replicate_424/versions/ab58679.py). This is evidence of an architectural change, not merely a rewritten file containing equivalent logic. The agent's geometric interpretation is a recorded claim, not an independent validation of the simulator's mass distribution.

**2. Replicate 24 adds observation before making a targeted repair.**

Add A* → rollout still fails → log phase transitions and route waypoints → increase trajectory sampling → observe the T moving during the approach → enlarge clearance and abandon/replan stale routes.

Follow [L69 → L73 → L77 → L81](runs/dynpusht2d_replicate_24/transcript.md#L69). L73 prints actual multi-waypoint routes. L77 shows the block's pose changing while the controller is still approaching. [Commit d523a1c](runs/dynpusht2d_replicate_24/diffs/d523a1c.diff) adds the disturbance checks and increases clearance. This is especially useful for studying the coding agent's choice to obtain more diagnostic information. It does not establish that the static geometry model became a contact-dynamics model.

**3. Replicate 24 sometimes throws away a computed route.**

Near-goal shortcut discards A* route → agent identifies a problematic case → restricts shortcut to routes of at most two waypoints → tests that restriction → reverts it.

See [L535–L545](runs/dynpusht2d_replicate_24/transcript.md#L535), [restriction](runs/dynpusht2d_replicate_24/diffs/3891024.diff), and [revert](runs/dynpusht2d_replicate_24/diffs/37b79db.diff). The intervening ten-seed test reports 6/10. The revert's title says “higher-scoring”; this short sequence alone is not a controlled, matched comparison proving the shortcut is better. The final code still discards the planned translation-approach route when the block is within 0.15 of its target (lines 149–151). A planner being present does not mean every action follows its output.

## What this adds to the Obstruction2D/Rovers comparison

The phase-based structure also appears in both inspected DynPushT2D runs. The stronger claim “these agents never write explicit planning” does not hold: both DynPushT2D controllers and Rovers 424 contain route search. The inspected Obstruction2D controller instead used phase rules and geometric/anticipatory constraints without comparable route search.

A useful hypothesis to test is: **agents add explicit search for navigation while handling contact manipulation with analytic rules and feedback.** These cases motivate that hypothesis; they do not establish its prevalence or explain why the agent chose that division.

A small next experiment would separately measure route execution and contact control: hold the goal error roughly fixed while changing whether the robot must go around the T, then measure planner calls, retained/discarded waypoints, and contact-induced pose changes. Disabling A* while holding the push rules fixed would test its contribution. These interventions have not been run.

## Files to inspect, in order

1. [424 analysis](runs/dynpusht2d_replicate_424/analysis.md) and [24 analysis](runs/dynpusht2d_replicate_24/analysis.md): exact code locations and evidence limits.
2. Final [424 approach.py](runs/dynpusht2d_replicate_424/approach.py), especially lines 57–122, 148–170, 180–222, 232–302; final [24 approach.py](runs/dynpusht2d_replicate_24/approach.py), especially lines 44–99, 110–151, 171–180, 247–257.
3. Their `transcript.md` files at the events above. `L` denotes the original `stream.jsonl` line, not a robot time step.
4. Their `versions/`, `diffs/`, and `policy_history.json`: all 11 and 77 saved commits affecting `approach.py`, respectively. These counts include reverts; they are not counts of successful repairs or independent runs.

Final programs were read in full; main messages, selected diagnostic outputs and relevant history changes were inspected. Backend/subagent session reasoning was not audited here. Absence claims concern the final controllers, not every development helper or unseen internal computation. `results.json` was not used to rank or select cases; quoted tests are development evidence, not a fresh success-rate estimate. Source hashes and provenance are in each run's `evidence_manifest.json` and the shared `sample_manifest.json`. Repeated test seeds, resumed turns, and policy revisions are not counted as independent runs. The archive was only read.

These are code-mechanism annotations under [the pilot rules](annotation_rules.md), not a completed ACT*ONOMY labeling of the development transcript.
