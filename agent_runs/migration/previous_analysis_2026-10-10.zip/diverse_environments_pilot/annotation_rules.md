# Working annotation rules, v0.1

Unit: one saved final controller, with supporting modules followed through its call path. Use history to locate introduction or removal of mechanisms. Keep separate annotations for development tools, readable explanations, and final policy behavior.

These are operational code-mechanism labels for this pilot, not new ACT*ONOMY categories. ACT*ONOMY can separately describe the coding agent's observable activities. Internal model-based reasoning is not inferred from the controller architecture.

| Field | Positive evidence | Insufficient evidence |
| --- | --- | --- |
| Phase-based decomposition | Persistent stages/subtasks whose state and transition conditions control actions across calls; may be a finite-state machine, behavior tree, or persistent task queue | Many functions; comments describing steps; mere proposals |
| Anticipatory constraints | Candidate choice depends on later tasks, intended placements or predicted interference | A response only after a failure |
| One-step prediction | A computed next-state quantity affects action selection | A goal coordinate with no consequence calculation |
| Multi-step geometric look-ahead | Successor positions/configurations, feasibility tests, and costs/routes are computed before execution and used to choose motion | A sorted list of objects or isolated static collision checks |
| Multi-step dynamics look-ahead | A transition/dynamics model rolls out candidate action sequences and predicted outcomes affect the chosen action | Calling the real task environment during development |
| Task-level search | Alternative operator/subgoal sequences are expanded with preconditions/effects or another predictive representation | A fixed sample → photograph → send script |

These labels can coexist. A phase controller can call a planner. Search over several candidate positions is not automatically multi-step search; inspect whether successors form a route. Direct analytic prediction does not require a tree search to count as prediction.

For each positive label record: source and line, mechanism, input/state representation, alternatives considered, consequence calculation, where its result reaches `get_action`, and whether evidence is implemented, historically executed, merely proposed, or removed. State whether the code implements the algorithm or invokes a library implementation. An algorithm written in the generated file is not thereby a novel invention.

Use `supported`, `not found in inspected final code`, or `uncertain`; pending cases remain `not annotated`, never negative. State the inspection scope for absence claims. A keyword/function-name match only locates evidence. Comments and agent explanations must be checked against executable code.

For phase transitions, distinguish a requested operator from a confirmed environmental effect. For model claims, distinguish idealized geometry from a validated dynamics model. A model can be wrong and still be used for planning. Record fallbacks that bypass the planner's feasibility checks.

Do not count inherited session history, repeated evaluations, overlapping excerpts, or several policy revisions as independent agent runs. Do not infer difficulty from raw step limits or compare success percentages across different task mixtures.

First review question: does separating persistent phase structure, geometric path search, and task-level search capture the distinctions we want? Rovers 424 is a positive example of the first two and has no task-level search in the inspected final program.
