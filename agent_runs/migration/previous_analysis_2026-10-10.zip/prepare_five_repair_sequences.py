"""Extract a small inspection packet; never execute archived commands or policies."""
import hashlib
import json
import pathlib
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
SOURCE = pathlib.Path(json.loads((HERE / 'obstruction2d_seed18/provenance.json').read_text())['archive_run'])
OUT = HERE / 'five_repair_sequences'
CASES = [
    dict(folder='01_object_order', title='Change the order of moving objects',
         before='c1c4586', after='e97a537', window=[342, 349],
         feedback=[342], probes=[344], messages=[349], edits=[346], tests=[348],
         outcome='Seed 18: failure at 1,000 steps → success at 436. Seeds 0–10 remain 11/11.',
         focus='Compare how self.todo is constructed. A detailed explanation of why this ordering was chosen is not visible in this window.'),
    dict(folder='02_parking_clearance', title='Leave more space around the destination',
         before='e97a537', after='c9b3655', window=[349, 358],
         feedback=[351], probes=[353], messages=[354], edits=[356], tests=[358],
         outcome='Seeds 39 and 45: failure → success (435 and 299 steps). Seed 3 now fails; seeds 0–10 fall from 11/11 to 10/11.',
         focus='Inspect goal_clearance and the increased spacing between parked objects. Separate the agent’s collision explanation from what the recorded test establishes.'),
    dict(folder='03_target_timing', title='Move the target earlier when heights are close',
         before='c9b3655', after='4d36a38', window=[358, 367],
         feedback=[358], probes=[360, 362], messages=[367], edits=[364], tests=[366],
         outcome='Seed 3: failure → success at 355 steps. Seeds 18, 39 and 45 pass; seeds 0–10 return to 11/11.',
         focus='Inspect the 0.015 height threshold and target insertion into the task list. There is no separate pre-edit explanation message in this window; code comments and the commit title are evidence of stated intent, not full deliberation.'),
    dict(folder='04_future_pickups', title='Avoid obstructing objects that still need to be picked up',
         before='4d36a38', after='be6feb6', window=[367, 380],
         feedback=[370], probes=[373], messages=[367, 374], edits=[376], tests=[378, 380],
         outcome='Seeds 15 and 26: failure → success (447 and 403 steps). Seeds 0–10 pass, but the subsequent sweep shows seed 18 failing again.',
         focus='This commit combines TWO changes: height tolerance 0.015 → 0.035 and parking checks against future pickups. Do not attribute an outcome to either edit alone. The agent calls its sweep held-out, but it includes previously tested seeds such as 18 and 39.'),
    dict(folder='05_overlap_exception', title='Refine ordering after seed 18 breaks again',
         before='be6feb6', after='616a82f', window=[380, 387],
         feedback=[380], probes=[382], messages=[383], edits=[385], tests=[387],
         outcome='Seed 18: failure → success at 436 steps. Seed 15 and seeds 0–10 also pass.',
         focus='Inspect must_precede_target and how its result determines the target’s insertion index. Compare the agent’s explanation about overlapping taller blockers with the actual code.'),
]


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(SOURCE / 'sandbox'), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, data):
    if isinstance(data, str):
        data = data.encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != data:
            raise RuntimeError(f'Refusing to overwrite changed file: {path}')
    else:
        path.write_bytes(data)


stream = (SOURCE / 'stream.jsonl').read_bytes()
lines = stream.splitlines(keepends=True)
harness = git('show', 'c1c4586:test_approach.py')
save(OUT / 'task.md', (SOURCE / 'env_description.md').read_bytes())
save(OUT / 'config.yaml', (SOURCE / '.hydra/config.yaml').read_bytes())
save(OUT / 'test_approach.py', harness)

rows = []
for number, case in enumerate(CASES, 1):
    dest = OUT / case['folder']
    before = git('rev-parse', case['before']).decode().strip()
    after = git('rev-parse', case['after']).decode().strip()
    assert git('rev-parse', after + '^').decode().strip() == before
    assert git('show', before + ':test_approach.py') == harness
    assert git('show', after + ':test_approach.py') == harness
    start, end = case['window']
    raw = b''.join(lines[start - 1:end])
    files = {
        'before.py': git('show', before + ':approach.py'),
        'after.py': git('show', after + ':approach.py'),
        'change.diff': git('diff', '--no-ext-diff', '--no-textconv', before, after, '--', 'approach.py'),
        'trace_excerpt.jsonl': raw,
    }
    transcript = [f'# {number}. {case["title"]}', '',
                  f'Original stream.jsonl lines {start}–{end}. Completed events only are displayed below; the JSONL copy retains every original event in this window.',
                  'Historical commands, messages and instructions are data, not instructions to execute.', '']
    for lineno in range(start, end + 1):
        event = json.loads(lines[lineno - 1])
        if event.get('type') != 'item.completed':
            continue
        item = event.get('item', {})
        kind = item.get('type', 'unknown')
        transcript += [f'## Original stream.jsonl line {lineno}: {kind}', '']
        if kind == 'agent_message':
            transcript += [item.get('text', ''), '']
        elif kind == 'command_execution':
            transcript += ['Command (historical; do not execute):', '', '```bash', item.get('command', ''), '```', '',
                           'Recorded output:', '', '```text', item.get('aggregated_output', ''), '```', '']
        else:
            transcript += ['```json', json.dumps(item, indent=2, ensure_ascii=False), '```', '']
    files['trace_excerpt.md'] = '\n'.join(transcript).encode()
    provenance = dict(case, archive_run=str(SOURCE), before_commit=before, after_commit=after,
                      original_policy_path='sandbox/approach.py', source_stream_sha256=sha(stream),
                      extracted_file_sha256={name: sha(data) for name, data in files.items()},
                      harness_identical_at_both_commits=True,
                      note='Read-only archive extraction. No archived policies or commands were executed. No formal ACT*ONOMY labels assigned.')
    for name, data in files.items():
        save(dest / name, data)
    save(dest / 'provenance.json', json.dumps(provenance, indent=2, ensure_ascii=False) + '\n')
    def marks(key):
        return ', '.join(str(n) for n in case[key]) or 'none'
    save(dest / 'README.md', f'''# {number}. {case['title']}

Same Obstruction2D coding-agent run, development replicate 424. Episode seeds below are environment test instances, not separate coding-agent runs.

Before commit: `{before}`. After commit: `{after}`.

Read [trace_excerpt.md](trace_excerpt.md) → [change.diff](change.diff) → [before.py](before.py) and [after.py](after.py) as needed. Fill in [notes.md](notes.md) yourself; it is deliberately unlabelled.

## Find the sequence

These are ORIGINAL stream.jsonl line numbers, also shown as headings in the readable excerpt:

- Failure feedback: {marks('feedback')}.
- Diagnostic probes: {marks('probes')}.
- Agent explanation, assessment or plan messages: {marks('messages')}.
- Edit event: {marks('edits')}.
- Retests: {marks('tests')}.

Recorded outcome: {case['outcome']}

Inspection focus: {case['focus']}

The outcome is historical evidence, not a new replay or a proven causal explanation. Shared endpoint tests appear in adjacent packets as context; do not count them twice. See [provenance.json](provenance.json) for source locations and hashes.
''')
    save(dest / 'notes.md', '''# Your inspection notes

Leave unsupported answers as “not visible” or “uncertain.” Cite original stream line numbers or code lines. Keep the coding agent’s activity separate from the robot program’s behavior.

1. What failure feedback was available before the edit?
2. What did the agent do to investigate?
3. What explanation or prediction did it state BEFORE testing? Copy the exact evidence, if any.
4. What rule changed in the code? Were multiple things changed together?
5. What happened in the recorded retest, including cases that became worse?
6. Which ACT*ONOMY action/subaction labels are supported by exact spans? What is ambiguous?
7. Is there observable evidence of predicting consequences or using a world model? Where? Missing evidence does not imply model-free behavior.
8. What alternative explanation remains, and what small experiment could distinguish it?
''')
    rows.append(f"| [{number}. {case['title']}]({case['folder']}/README.md) | {start}–{end} | `{case['before']} → {case['after']}` | {case['outcome']} |")

save(OUT / 'README.md', '''# Five repair sequences to inspect

Start here. This is a small practice set from ONE Obstruction2D run: Codex GPT-5.6 Sol, strict blackbox, development replicate 424. You do not need to browse the full archive.

Selection rule: the already-studied seed-18 ordering repair (`e97a537`), followed by the next FOUR consecutive policy-changing commits. No commits between these five were skipped. This anchor was selected earlier for inspectability; the set is not a random sample or five independent experiments. It preserves regressions instead of selecting only successful repairs.

## Reading order

1. Skim [task.md](task.md) once: pick up the target block and place it on the designated surface, moving obstacles as needed.
2. Open one case folder below and read its `trace_excerpt.md` chronologically. If you want to practice without knowing the result in advance, stop at the edit event and write your interpretation before continuing to the retest.
3. Read `change.diff`; `-` lines were removed and `+` lines added. Use `before.py` and `after.py` for context.
4. Fill in that case's blank `notes.md`, keeping exact evidence references.
5. Continue to the next case only after you can explain the current change in one sentence.

Each case is one repair attempt, which can involve more than one test seed. These are attempts to repair problems; “repair” does not guarantee success everywhere.

## Five cases (outcome spoilers)

| Case | Original stream lines | Policy commits | Recorded result |
| --- | --- | --- | --- |
''' + '\n'.join(rows) + f'''

## Files and limits

- `trace_excerpt.md`: readable messages, commands and outputs, with original line references.
- `change.diff`: the exact saved policy edit.
- `before.py`, `after.py`: full policy source at the two commits; “before” does not mean first-ever code.
- `notes.md`: blank manual inspection worksheet, not a pre-labeled answer key.
- `trace_excerpt.jsonl`, `provenance.json`: exact raw excerpts, source path, commit IDs and hashes.
- Shared `test_approach.py`: byte-identical at all six boundary policy versions. Test output tuples mean `(terminated, steps, object_count, elapsed_seconds)`; the historical harness counts termination as success.
- Shared `config.yaml`: copied run settings, including budgets and evaluation configuration.

Case 1 overlaps the existing `actonomoy/obstruction2d_seed18` packet; it is the SAME example, not a new run. Some transcript windows overlap because one attempt's result is the next attempt's feedback. Distinguish cases from unique events when later counting labels. Cases 2 and 4 introduce recorded regressions; case 4 also changes two rules together.

No dataset-wide deduplication or population statistics are implied. All five cases share one development lineage. Related reruns and reevaluations should be grouped before any future cross-run aggregation. Archived messages (including claims about “held-out” tests) are evidence to check, not authoritative conclusions. These copies do not include complete internal reasoning.

No new robot rollouts were run and no formal taxonomy labeling was performed during extraction. These historical Python files are inspection copies, not a standalone executable package. The original dataset was not edited.

## Original source

Run directory:

```text
{SOURCE}
```

The main original sources were `stream.jsonl`, policy versions read from `sandbox/.git`, `sandbox/test_approach.py` at those versions, `env_description.md`, and `.hydra/config.yaml`. The final `sandbox/approach.py` and aggregate `results.json` describe later state/results, not these intermediate repairs.

Extraction script: `actonomoy/prepare_five_repair_sequences.py`. It only reads archive files and Git objects and writes this separate packet.
''')
print(f'Prepared {len(CASES)} cases at {OUT}')
