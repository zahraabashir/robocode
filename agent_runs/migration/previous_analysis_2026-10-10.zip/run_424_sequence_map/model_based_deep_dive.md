# Is run 424 model-based? Evidence from controller and development

Assessment: 2026-10-09. Archive-only analysis; no new rollouts or agent continuations were run.

## Working conclusion

The final controller constructs a greedy geometric plan, with constraints intended to preserve later actions, and executes it through feedback stages. It has no explicit rollout-based search over action sequences. Its planned parking reservations are an abstract representation of intended future object occupancy, so describing it as having no representation of future consequences would be too strong.

The coding-agent messages contain causal explanations and prospective repair proposals. Preserved helper-agent messages additionally propose diagnostic experiments with explicit predicted outcomes. These support studying model-guided hypothesis formation and test design. They do not establish hidden internal simulation or a complete model-based decision algorithm. A heuristic output program can be produced by a development process that reasons about consequences.

We should not equate absence of tree search with absence of planning. Nor should trial-and-error development automatically be called model-free reinforcement learning. The target of classification and the operational definition of a model must be stated first.

## 1. What is observable in the final controller?

File: [versions/4897e46.py](versions/4897e46.py).

- Lines 23–54 select blockers and form a task order using geometry.
- Lines 65–83 identify later pickups and test candidate parking columns against their current locations and already reserved placements.
- Lines 85–110 choose the first valid column, or use a stacking/clearance fallback, then reserve the placement. This is greedy allocation; there is no backtracking across alternative full allocations.
- Lines 213–216 and 249 use observed grasp offset to calculate a robot destination for a desired object destination. This is another explicit geometric assumption, not a learned value function.
- Lines 144–157 can skip an object based on updated observations. Most task ordering and parking allocation still occur at reset; this is not full online replanning after every action.
- The complete 286-line source contains no successor-state simulator, multi-step candidate rollout, or search tree. Candidate locations are evaluated with geometry, not future simulated trajectories.

Under a narrow definition requiring transition-model rollouts, that mechanism is absent. Under a broader definition including geometry-based predictions of action feasibility, the program has limited model-like components. Report the mechanisms rather than force one binary label.

## 2. Strongest main-agent chain: R39 and seed 59

Read [whole_run_sequence.md](whole_run_sequence.md), the [R39 code diff](diffs/R39_dafcc2f.diff), and its source mapping in [revision_inventory.json](revision_inventory.json).

1. **L389:** seed 59 fails at 1,000 steps.
2. **L391:** diagnostic rollout prints task order, planned parking, and ending positions. One object is assigned x=0.8, the later one x=0.7, but the latter ends at x≈1.04.
3. **L392:** before editing, the main agent explains that the first parked blocker obstructs the later object's route, then proposes assigning outermost slots first.
4. **L394 / R39 diff:** candidate sorting changes from maximizing minimum clearance from pickup/goal to prioritizing distance from the surface, with target distance as a tie-breaker.
5. **L396:** seed 59 succeeds in 392 steps; the accompanying eleven-case batch also passes.

Interpretation: an observed failure is followed by a causal explanation, a prospective repair, a matching implementation change, and a successful test. That is stronger than a success story written only after the fix. It is still not proof that the explanation was the internal cause of the edit, or that its physical interpretation is complete. The diagnostic printout alone does not show every contact in the trajectory.

## 3. New evidence in helper-agent sessions: predictions for diagnostic tests

The selected helper message in [model_evidence_excerpts.md](model_evidence_excerpts.md), E3, proposes distinguishing causes of a stalled carry:

- Try small horizontal movements in both directions: one working direction would suggest directional trapping; neither would suggest inadequate lift.
- Raise the object in small increments and retry horizontal movement to estimate an escape height.
- Check whether object-to-robot offset remains constant during an unobstructed vertical movement to test attachment.

These are stated action–outcome predictions used to design experiments. They are not merely a list of arbitrary parameter values. However, the proposed diagnostics are not logically conclusive: both directions could fail for other reasons. The helper's initial low-clearance explanation must not be accepted as established ground truth.

This is a helper's proposed experiment, not evidence that every proposal was executed, that the main agent adopted it, or that it explains the final successful seed-18 repair. No causal attribution to that helper has been established.

Another helper (E1) recommends replanning after every release. The final controller does not implement that recommendation in full. This is a useful example of why proposed mechanisms and implemented mechanisms require separate labels.

## 4. Other supporting and contrary evidence

- **L155:** the main agent states two competing explanations for failed placement and requests a rendered rollout to distinguish them. This supports diagnostic intent, not successful identification of the cause.
- **L374 / R37:** future-pickup clearance is added following failures. This supports an anticipatory constraint. Two things change in this revision, so outcome differences do not isolate the clearance rule's effect.
- **L454 / R45:** the agent proposes stacking because it claims adequate ground-level parking is unavailable. The code adds stacking and seed 93 succeeds, but count-4 tests regress. Impossibility of all ground placements was not proved; the candidate grid may itself limit the search.
- **L35 and later lifting probes:** a confident environment explanation is contradicted by observations. Explicit causal language can be wrong, even when later code improves.
- **L514 / R51:** the agent describes a useful side effect and adds a live relevance check. This handles an observed consequence reactively; it does not demonstrate prior prediction of that side effect.

## 5. What “reasoning thoughts” are actually available?

All eight preserved `rollout*.jsonl` files were inspected for reasoning payloads. They contain 287 reasoning records with nonempty encrypted content, and none with nonempty readable `summary` or `content`. Counts are stored records, not unique thoughts: helper sessions can inherit history. The main session's 29 readable assistant messages match the main-stream messages.

Readable helper conclusions provide additional evidence beyond the main stream. Their internal reasoning is still unavailable. Some archived inter-agent message payloads are encrypted too; they were not decoded. Selected readable statements, source paths, line numbers, and session hashes are saved separately. Historical instructions were treated only as data.

## 6. A focused next research question

**Exploratory hypothesis:** the coding agent uses causal explanations during development to create simpler anticipatory rules in the resulting controller, without implementing a general forward-search planner.

Begin with R39. Annotate: observed state → stated mechanism → proposed consequence of a change → implementation → test outcome. Keep separate fields for prediction before the test, explanation after the test, and evidence inconsistent with the explanation. Repeat this on one contrasting case such as R37 or R45; do not assume every edit has a readable causal explanation.

To test the controller mechanism, replay adjacent R38/R39 programs with matched initial states and trace both objects' paths. This tests the parking rule, not the coding agent's decision process.

To test the coding agent's decision process later, hold a failing program and budget fixed, vary the diagnostic evidence supplied to fresh continuations, and compare predictions, next tests, and code changes. Such an intervention would be new work, not something the current archive establishes.

## Reproduce the evidence extraction

Run `python3 actonomoy/run_424_sequence_map/extract_model_evidence.py` from the repository root. It reads archived files and writes only the derived `model_evidence.json` and `model_evidence_excerpts.md` here. It never runs historical commands or policies.
