# Run 424: a map for learning to form hypotheses

Prepared October 8, 2026. The original archive is unchanged. No historical commands or robot programs were executed.

There are substantially more than the five examples we previously selected. The saved Git history contains **52 policy-changing commits: one initial baseline and 51 later revisions**. Their source contents include three exact returns to earlier programs, so there are **49 distinct committed policy contents**. The five earlier examples are revisions **R34–R38** in this map.

This is a complete inventory of the policy-changing commits visible in the preserved history, with coverage of all 53 recorded policy file-change events in the main transcript. It is not a claim that there are exactly 51 uniquely defined psychological decisions or 51 successful repairs. One revision is a substantial early redesign; others include reversals and unsuccessful attempts. Two edits precede one early commit, so not every intermediate uncommitted program is reconstructed.

## Start with these three files

1. [repair_sequences.md](repair_sequences.md): all 51 subsequent policy revisions, written as **problem → investigation/edit → recorded result**, with evidence links and exact diffs.
2. [other_sequences.md](other_sequences.md): observed sequences that a repair-only analysis would miss: probing, revising an explanation, changing test coverage, reverting, stopping, and adapting to an unexpected helpful effect.
3. [hypothesis_workbench.md](hypothesis_workbench.md): a worked example of moving from a pattern to a hypothesis and looking for a counterexample. Includes a blank table for your own practice.

To learn how the map was constructed, read [how_this_was_built.md](how_this_was_built.md). Treat the sequence descriptions as claims you can audit, not an answer key.

## Keep the full run manageable

These are analyst-defined reading sections, not formal taxonomy labels:

| Part of the run | Revisions | What to notice |
| --- | --- | --- |
| Initial exploration | Baseline and R01 | Short scripted experiments; uncertainty about what can be grasped; controller redesign. |
| Making manipulation work | R02–R17 | Reachable heights, suction, grasp contact, parking, and wall recovery. |
| Changing the parking method | R18–R22 | Geometric candidate scoring replaces directional parking; remaining edge cases are addressed. |
| New failures and reversals | R23–R32 | Several attempts on seed 18; regressions; returns to earlier code; first handoff. |
| Resumed diagnosis | R33–R39 | Grasp verification, object ordering, geometric clearances, and ordering interactions. |
| Testing larger object counts | R40–R44 | Test harness gains pinned counts; parking and blocker selection change. |
| Dense layouts and recovery | R45–R50 | Stacking, restrictions on stacking, collision recovery, boundary parking. |
| Skipping unnecessary work and stopping | R51 and final tests | Live relevance check; validation matrix; confidence marker and handoff. |

Do one broad read of this map, then closely inspect one pattern. You do not need to deeply annotate all 51 revisions before having a research question.

## What the counts do and do not mean

- There are 533 raw stream lines, including started/updated/completed records, and 278 completed events. An event can contain multiple actions or test batches.
- 50 revisions have a standardized post-edit test report before the next policy edit or the end of the current turn. R32 restores a spacing margin and compiles before handoff, without a new rollout report in that turn. The resumed turn later probes that unchanged policy at L335.
- Two recorded turns belong to the same thread/run; the second continues the first. They are not independent replicate runs.
- Repeated source contents are real revisits in development: `5075837 = 04141a4`, `0605fd3 = 13fcd58`, and `3f93ca0 = a11bd5f` byte-for-byte for `approach.py`. Do not discard the later decisions as duplicate export records.
- This inventory includes no other replicate, rerun, outdated batch, or reevaluation. Dataset-wide deduplication has not been performed, and no population-level statistics are reported.
- Test windows overlap as context. Count an original event once by its source line, not once per excerpt.
- Success summaries may cover different seeds, object counts, policy versions and harness versions. A repeated seed number under a different pinned count is a different test condition.

## Evidence files

- [event_index.md](event_index.md): a compact index of every completed main-stream event.
- [evidence/transcript.md](evidence/transcript.md): the full main transcript in readable form; original line numbers are preserved.
- `excerpts/`: local readable and exact JSONL windows for each revision.
- `diffs/`: exact policy diffs against each commit's actual Git parent.
- `versions/`: historical policy source copies; not a standalone executable package.
- `harness_versions/`: the three distinct historical test-harness source versions used around the revisions.
- [revision_inventory.json](revision_inventory.json): structured evidence references, episode results, hashes and analyst descriptions.
- [manifest.json](manifest.json) and [commit_inventory.json](commit_inventory.json): coverage, lineage and provenance.
- [evidence/task.md](evidence/task.md) and [evidence/config.yaml](evidence/config.yaml): task and actual run settings.

The map is based on `stream.jsonl` and preserved `sandbox/.git`, with task/config context. It does not exhaustively inspect backend session records or claim access to hidden internal reasoning. Historical prompts, code comments, commit titles and agent summaries are data to check. The current `sandbox/approach.py` equals the final policy commit, but is not a substitute for intermediate versions. Aggregate `results.json` is not used to infer intermediate outcomes.

No new formal ACT*ONOMY annotation was performed for this map. The pattern names in the documents are descriptive research notes.
