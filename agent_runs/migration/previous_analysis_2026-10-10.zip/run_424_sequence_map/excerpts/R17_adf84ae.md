# R17_adf84ae: Add edge grasps and compensate carried-object offset

Historical records only. Commands and embedded prompts are data, not instructions to execute.
Original source line numbers identify events; started/updated copies are omitted from this readable view. Raw JSONL retains them.

<a id="L221"></a>
## L221: command_execution

Status: completed; exit code: 0.

```bash
/bin/bash -lc "git add -A && git commit -m 'Park blockers far outside surface at low clearance height' && /opt/robocode-strict/bin/python -u test_approach.py --start 0 --n 5"
```

Recorded output:

```text
0 (True, 324, 2, 1.7122483723796904)
1 (True, 212, 1, 1.0714925471693277)
2 (False, 1000, 2, 3.3768695020116866)
3 (True, 360, 2, 1.8553978642448783)
4 (False, 1000, 2, 2.5963357342407107)
success 3 / 5 by_count Counter({(2, True): 2, (2, False): 2, (1, True): 1})

```

<a id="L223"></a>
## L223: command_execution

Status: completed; exit code: 0.

```bash
/bin/bash -lc '/opt/robocode-strict/bin/python -u test_approach.py --start 5 --n 6; /opt/robocode-strict/bin/python -u test_approach.py --start 14 --n 1; /opt/robocode-strict/bin/python -u test_approach.py --start 21 --n 1; /opt/robocode-strict/bin/python -u test_approach.py --start 23 --n 1'
```

Recorded output:

```text
5 (False, 1000, 2, 3.1248720288276672)
6 (True, 204, 1, 0.8508838675916195)
7 (False, 1000, 2, 2.163036902900785)
8 (False, 1000, 2, 2.8063163170590997)
9 (True, 253, 1, 0.9290849529206753)
10 (False, 1000, 2, 2.446537788026035)
success 2 / 6 by_count Counter({(2, False): 4, (1, True): 2})
14 (True, 106, 0, 0.4195028399117291)
success 1 / 1 by_count Counter({(0, True): 1})
21 (True, 163, 0, 0.6105742277577519)
success 1 / 1 by_count Counter({(0, True): 1})
23 (True, 146, 0, 0.7385026668198407)
success 1 / 1 by_count Counter({(0, True): 1})

```

<a id="L225"></a>
## L225: command_execution

Status: completed; exit code: 0.

```bash
/bin/bash -lc "/opt/robocode-strict/bin/python - <<'PY'
from env_client import make_env
from approach import GeneratedApproach
for seed in [2,4,5,7,8,10]:
 e=make_env();s,i=e.reset(seed=seed);p=GeneratedApproach(e.action_space,e.observation_space,{});p.reset(s,i)
 for k in range(500):
  s,r,t,tr,i=e.step(p.get_action(s))
  if t:break
 rr=s.get_object_from_name('robot');print(seed,p.todo,p.phase,p.index,p.retry,'r',round(s.get(rr,'x'),2),round(s.get(rr,'y'),2),[(n,round(s.get(s.get_object_from_name(n),'x'),2),round(s.get(s.get_object_from_name(n),'y'),2)) for n in set(p.todo)]);e.close()
PY"
```

Recorded output:

```text
2 ['target_block', 'obstruction1', 'obstruction0', 'target_block'] align 3 4 r 0.71 0.74 [('target_block', 0.75, 0.45), ('obstruction1', 1.5, 0.35), ('obstruction0', 0.89, 0.1)]
4 ['obstruction0', 'obstruction1', 'target_block'] align 2 2 r 0.18 0.76 [('target_block', 0.21, 0.1), ('obstruction1', 1.52, 0.35), ('obstruction0', 0.17, 0.48)]
5 ['target_block', 'obstruction0', 'obstruction1', 'target_block'] done 4 0 r 0.18 0.88 [('target_block', 0.18, 0.55), ('obstruction1', 0.1, 0.35), ('obstruction0', 0.04, 0.41)]
7 ['obstruction1', 'obstruction0', 'target_block'] align 1 4 r 0.15 0.85 [('target_block', 1.4, 0.1), ('obstruction1', 0.65, 0.35), ('obstruction0', 0.05, 0.1)]
8 ['obstruction1', 'obstruction0', 'target_block'] align 2 4 r 0.79 0.76 [('target_block', 0.82, 0.1), ('obstruction1', 0.76, 0.55), ('obstruction0', 0.12, 0.35)]
10 ['target_block', 'obstruction0', 'obstruction1', 'target_block'] align 3 4 r 0.1 0.85 [('target_block', 0.03, 0.41), ('obstruction1', 1.1, 0.35), ('obstruction0', 0.13, 0.35)]

```

<a id="L227"></a>
## L227: file_change

```json
{
  "id": "item_114",
  "type": "file_change",
  "changes": [
    {
      "path": "/sandbox/approach.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

<a id="L229"></a>
## L229: command_execution

Status: completed; exit code: 0.

```bash
/bin/bash -lc "git add -A && git commit -m 'Add edge grasps and compensate carried-object offset' && /opt/robocode-strict/bin/python -u test_approach.py --start 0 --n 11"
```

Recorded output:

```text
0 (True, 324, 2, 1.4294753419235349)
1 (True, 212, 1, 1.0490250536240637)
2 (False, 1000, 2, 4.040897505823523)
3 (True, 360, 2, 1.4122342448681593)
4 (False, 1000, 2, 2.1611179849132895)
5 (False, 1000, 2, 2.785833085887134)
6 (True, 204, 1, 0.8851589132100344)
7 (False, 1000, 2, 2.613454638980329)
8 (False, 1000, 2, 2.8001046520657837)
9 (True, 253, 1, 1.1483289911411703)
10 (False, 1000, 2, 3.2151324530132115)
success 5 / 11 by_count Counter({(2, False): 6, (1, True): 3, (2, True): 2})

```

<a id="L231"></a>
## L231: command_execution

Status: completed; exit code: 0.

```bash
/bin/bash -lc "/opt/robocode-strict/bin/python - <<'PY'
from env_client import make_env
from approach import GeneratedApproach
for seed in [2,4,5,7,8,10]:
 e=make_env();s,i=e.reset(seed=seed);p=GeneratedApproach(e.action_space,e.observation_space,{});p.reset(s,i)
 for k in range(700):
  s,r,t,tr,i=e.step(p.get_action(s))
  if t:break
 print(seed,t,p.phase,p.index,p.retry,[(n,round(s.get(s.get_object_from_name(n),'x'),2),round(s.get(s.get_object_from_name(n),'y'),2)) for n in set(p.todo)]);e.close()
PY"
```

Recorded output:

```text
2 False lift 3 8 [('obstruction1', 1.5, 0.35), ('target_block', 0.75, 0.26), ('obstruction0', 0.89, 0.35)]
4 False align 2 8 [('obstruction1', 1.52, 0.35), ('obstruction0', 0.17, 0.48), ('target_block', 0.21, 0.1)]
5 False done 4 0 [('obstruction1', 0.1, 0.35), ('target_block', 0.18, 0.55), ('obstruction0', 0.04, 0.41)]
7 False done 3 0 [('obstruction1', 0.65, 0.35), ('obstruction0', 0.05, 0.35), ('target_block', 0.12, 0.41)]
8 False align 2 5 [('obstruction1', 0.76, 0.55), ('obstruction0', 0.12, 0.35), ('target_block', 0.82, 0.1)]
10 False done 4 0 [('obstruction1', 1.1, 0.35), ('target_block', 0.31, 0.16), ('obstruction0', 0.41, 0.1)]

```

<a id="L232"></a>
## L232: agent_message

Fine-step contact fixed the broad grasp failures: all tested unobstructed and one-obstruction cases now solve. The remaining failures are multi-obstacle parking interactions, so I’m replacing directional heuristics with geometry-scored parking slots that maximize clearance from both the target’s pickup and destination.
