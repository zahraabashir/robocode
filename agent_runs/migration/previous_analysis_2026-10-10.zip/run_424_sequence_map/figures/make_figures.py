"""Descriptive figures from recorded main-stream events; no policy execution."""
import json
import os
from pathlib import Path
import re
from collections import defaultdict

os.environ.setdefault('MPLCONFIGDIR', '/tmp/robocode424-mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch, Rectangle
import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
raw = [json.loads(s) for s in (ROOT/'evidence/stream.jsonl').read_text().splitlines()]
revisions = json.loads((ROOT/'revision_inventory.json').read_text())
commit_to_revision = {r['commit_line']: int(r['id'][1:]) for r in revisions}
edit_lines = [n for r in revisions for n in r['edit_lines']] + [9]
completed = {n: e['item'] for n,e in enumerate(raw,1) if e['type']=='item.completed'}
event_positions = {n: k for k,n in enumerate(completed,1)}
invocation = re.compile(r'/bin/python(?:\s+-u)?\s+test_approach\.py((?:\s+--(?:start|n|count)\s+\d+|\s+--verbose)*)')
episode_pattern = re.compile(r'^(\d+) \((True|False), (\d+), (\d+), ([\d.eE+-]+)\)$')
starts = {}; turn = 0; batches = []; harness_commands = []; incomplete = []
for line,e in enumerate(raw,1):
    if e['type']=='turn.started':
        turn += 1
    item=e.get('item',{}); key=(turn,item.get('id'))
    if e['type']=='item.started':
        starts[key]=line
    if e['type']!='item.completed' or item.get('type')!='command_execution':
        continue
    calls=invocation.findall(item.get('command',''))
    if not calls:
        continue
    start_line=starts.get(key,line)
    assert not any(start_line < n < line for n in edit_lines), 'Test overlaps a policy edit'
    revision=commit_to_revision.get(line)
    if revision is None:
        revision=max((r for n,r in commit_to_revision.items() if n<start_line), default=0)
    harness_commands.append(dict(line=line,start_line=start_line,revision=revision))
    groups=[]; current=[]
    for text in item.get('aggregated_output','').splitlines():
        m=episode_pattern.match(text)
        if m:
            seed,ok,steps,count,seconds=m.groups()
            current.append(dict(seed=int(seed),passed=ok=='True',steps=int(steps),object_count=int(count),seconds=float(seconds)))
        s=re.match(r'^success (\d+) / (\d+)',text)
        if s:
            solved,tested=map(int,s.groups())
            assert len(current)==tested and sum(r['passed'] for r in current)==solved,(line,current,s.groups())
            groups.append((current,solved,tested));current=[]
    assert not current, ('Unfinished episode rows',line)
    assert len(groups)<=len(calls),(line,len(groups),calls)
    for k,(episodes,solved,tested) in enumerate(groups):
        flags={a:int(b) for a,b in re.findall(r'--(start|n|count)\s+(\d+)',calls[k])}
        start=flags.get('start',0); expected=flags.get('n',10); count=flags.get('count')
        assert [p['seed'] for p in episodes]==list(range(start,start+expected)),(line,flags)
        if count is not None:
            assert all(p['object_count']==count for p in episodes)
        batches.append(dict(line=line,batch_index=k,revision=revision,start_line=start_line,
                            reset_mode='default' if count is None else 'pinned',pinned_count=count,
                            start_seed=start,requested_n=expected,solved=solved,tested=tested,episodes=episodes))
    if len(groups)<len(calls):
        incomplete.append(dict(line=line,completed_batches=len(groups),invocations=len(calls),exit_code=item.get('exit_code'),
                               reason='reset sampling failure' if 'Failed to sample initial state' in item.get('aggregated_output','') else 'interrupted/piped baseline test'))

# Same default-reset seeds 0–10, in a single complete recorded batch. A wider
# batch is eligible only when its observed subset includes every one of these seeds.
baseline=[]
for b in batches:
    if b['reset_mode']!='default':
        continue
    subset=[p for p in b['episodes'] if 0<=p['seed']<=10]
    if {p['seed'] for p in subset}==set(range(11)):
        baseline.append(dict(revision=b['revision'],line=b['line'],batch_index=b['batch_index'],
                             solved=sum(p['passed'] for p in subset),episodes=subset,
                             original_batch_n=b['tested']))
assert len({tuple(p['object_count'] for p in b['episodes']) for b in baseline})==1
by_revision=defaultdict(list)
for b in baseline:by_revision[b['revision']].append(b)
assert all(len({b['solved'] for b in bs})==1 for bs in by_revision.values())

# Heatmap: an explicit illustrative subset of difficult default-reset cases.
# Missing cells mean not recorded; they are never forward-filled.
selected=[3,15,18,26,39,45,53,59,85,93]
outcomes=defaultdict(list)
for b in batches:
    if b['reset_mode']=='default':
        for p in b['episodes']:
            outcomes[(p['seed'],b['revision'])].append(dict(line=b['line'],batch_index=b['batch_index'],**p))
matrix=np.full((len(selected),51),-1,dtype=int)
for row,seed in enumerate(selected):
    for revision in range(1,52):
        observations=outcomes.get((seed,revision),[])
        if observations:
            distinct={o['passed'] for o in observations}
            matrix[row,revision-1]=(int(next(iter(distinct))) if len(distinct)==1 else 2)

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':17,
                     'axes.labelsize':11,'axes.spines.top':False,'axes.spines.right':False,
                     'savefig.facecolor':'white','figure.facecolor':'white','svg.fonttype':'none'})
NAVY='#17324d'; BLUE='#3478a6'; TEAL='#087e8b'; ORANGE='#c25726'; GREY='#e8edf1'; INK='#293744'

def export(fig,name):
    fig.savefig(OUT/f'{name}.png',dpi=190,bbox_inches='tight')
    fig.savefig(OUT/f'{name}.svg',bbox_inches='tight')
    plt.close(fig)

# Figure 1: event raster. Positions are ordinal completed events, not time.
phases=[(1,78,'Explore\nmanipulation'),(79,231,'Repair movement\nand grasping'),(232,260,'Geometric\nparking'),
        (261,328,'New failures\nand reversals'),(329,403,'Resume; refine\nordering'),(404,447,'Expand object\ncounts'),
        (448,513,'Stacking and\nrecovery'),(514,533,'Final\nchecks')]
lanes={
    'Custom environment scripts':[n for n,i in completed.items() if i['type']=='command_execution' and 'from env_client import make_env' in i.get('command','') and "<<'PY'" in i.get('command','')],
    'Policy edits':[n for n,i in completed.items() if i['type']=='file_change' and any(c['path']=='/sandbox/approach.py' for c in i['changes'])],
    'Test-harness commands':[h['line'] for h in harness_commands],
    'Agent messages':[n for n,i in completed.items() if i['type']=='agent_message'],
}
fig,ax=plt.subplots(figsize=(14,4.8));fig.subplots_adjust(left=.205,right=.985,top=.69,bottom=.20)
for k,(start,end,label) in enumerate(phases):
    points=[p for n,p in event_positions.items() if start<=n<=end]
    left,right=min(points)-.5,max(points)+.5
    ax.axvspan(left,right,color=('#edf4f8' if k%2==0 else '#f9fafb'),zorder=0)
    ax.text((left+right)/2,3.78,label,ha='center',va='bottom',fontsize=9,color=NAVY)
for y,(name,ns) in zip([3,2,1,0],lanes.items()):
    ax.scatter([event_positions[n] for n in ns],[y]*len(ns),marker='|',s=230,linewidths=1.8,color=[TEAL,ORANGE,BLUE,NAVY][3-y])
boundary=(event_positions[327]+event_positions[331])/2
ax.axvline(boundary,color=NAVY,ls='--',lw=1)
ax.text(boundary,-.68,'turn boundary',ha='center',fontsize=8,color=NAVY)
ax.set(yticks=[3,2,1,0],yticklabels=list(lanes),ylim=(-.5,3.5),xlim=(.5,len(completed)+.5),xlabel='Position among completed main-transcript events (not elapsed time)')
ax.tick_params(axis='y',length=0,pad=10);ax.spines['left'].set_visible(False)
fig.text(.03,.97,'1  Development activity changes across the run',fontsize=18,weight='bold',color=NAVY,va='top')
fig.text(.03,.90,'Recorded actions, grouped by visible tool use. Background stages are analyst-defined reading sections.',fontsize=10,color=INK)
fig.text(.03,.035,'One coding-agent run · Selected event types only · A harness command can contain several batches or fail to complete · No ACT*ONOMY labels inferred',fontsize=9,color=INK)
export(fig,'01_development_timeline')

# Figure 2: no interpolation across revisions without a matching evaluation.
fig,ax=plt.subplots(figsize=(12,5));fig.subplots_adjust(left=.08,right=.98,top=.78,bottom=.24)
y=np.full(51,np.nan)
for revision,bs in by_revision.items():
    if revision:y[revision-1]=bs[-1]['solved']
x=np.arange(1,52);ax.plot(x,y,color=BLUE,marker='o',ms=5,lw=1.8)
ax.scatter(x[np.isnan(y)],np.full(np.isnan(y).sum(),-.65),marker='|',s=30,color='#9aa6af')
ax.axvspan(33.5,38.5,color=TEAL,alpha=.08)
ax.text(36,11.65,'R34–R38',ha='center',va='center',fontsize=9,color=TEAL)
for r,label,xytext in [(18,'Geometric parking\nR18: 8/11',(13,8.3)),(26,'High-carry change\nR26: 5/11',(24,2.3)),(35,'Seed 3 breaks\nR35: 10/11',(36,7.2))]:
    ax.annotate(label,xy=(r,y[r-1]),xytext=xytext,fontsize=9,color=INK,ha='center',arrowprops=dict(arrowstyle='-',color='#71808a'))
ax.set(xlim=(.3,51.7),ylim=(-1,11.9),xticks=[1,5,10,15,20,25,30,35,40,45,51],yticks=[0,2,4,6,8,10,11],
       xlabel='Saved policy revision (R01–R51)',ylabel='Solved cases among default-reset seeds 0–10')
ax.grid(axis='y',alpha=.2);ax.spines['left'].set_visible(False)
fig.text(.035,.97,'2  Performance on the same eleven development cases',fontsize=18,weight='bold',color=NAVY,va='top')
fig.text(.035,.90,'Observed results only. Gaps / grey ticks = no complete matching batch at that revision; no scores carried forward.',fontsize=10,color=INK)
fig.text(.035,.07,'Connected segments join adjacent measured revisions only. These repeatedly used development cases are not a held-out generalization estimate.',fontsize=9,color=INK)
fig.text(.035,.025,'A wider recorded batch is eligible when it contains all seeds 0–10. Pinned-count tests are excluded. The task gives 1,000 steps per episode.',fontsize=9,color=INK)
export(fig,'02_fixed_cases_performance')

# Figure 3: illustrative difficult cases, explicitly labelled as selected.
fig,ax=plt.subplots(figsize=(14,5.7));fig.subplots_adjust(left=.075,right=.985,top=.77,bottom=.24)
cmap=ListedColormap([GREY,ORANGE,TEAL,'#9a77b8']);norm=BoundaryNorm([-1.5,-.5,.5,1.5,2.5],4)
ax.imshow(matrix,cmap=cmap,norm=norm,aspect='auto',interpolation='nearest',extent=[.5,51.5,len(selected)-.5,-.5])
ax.set_xticks(np.arange(.5,52,1),minor=True);ax.set_yticks(np.arange(-.5,len(selected),1),minor=True)
ax.grid(which='minor',color='white',linewidth=.7);ax.tick_params(which='minor',length=0)
ax.set(xticks=[1,5,10,15,20,25,30,34,38,40,45,51],yticks=range(len(selected)),yticklabels=selected,
       xlabel='Saved policy revision (R01–R51)',ylabel='Episode seed (default reset)')
ax.add_patch(Rectangle((33.5,-.5),5,len(selected),fill=False,edgecolor=NAVY,linewidth=1.8))
ax.text(36,-.85,'R34–R38',ha='center',fontsize=9,color=NAVY)
ax.spines[['left','bottom']].set_visible(False)
legend=[Patch(color=TEAL,label='Recorded success'),Patch(color=ORANGE,label='Recorded failure'),Patch(color=GREY,label='No recorded test here')]
if (matrix==2).any():legend.append(Patch(color='#9a77b8',label='Conflicting repeats'))
fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.52,.105),ncol=len(legend),frameon=False,fontsize=10)
fig.text(.035,.975,'3  A case can succeed, fail again, and recover',fontsize=18,weight='bold',color=NAVY,va='top')
fig.text(.035,.905,'Ten selected difficult cases from the narrative; an illustrative subset, not a representative sample of episodes.',fontsize=10,color=INK)
fig.text(.035,.055,'Seed 18: fail R33 → pass R34 → fail R37 → pass R38. The fixed eleven-case score is 11/11 at R37.',fontsize=10,color=NAVY)
fig.text(.035,.015,'Grey cells do not mean failure or forgotten cases. Repeated observations at one revision are combined only when their outcomes agree.',fontsize=9,color=INK)
export(fig,'03_case_outcomes')

metadata=dict(completed_event_counts={name:len(ns) for name,ns in lanes.items()},
              test_harness_commands=len(harness_commands),complete_test_batches=len(batches),
              recorded_episode_rows=sum(len(b['episodes']) for b in batches),
              fixed_case_batches=len(baseline),fixed_case_measured_revisions=len(by_revision),
              fixed_case_revisions=sorted(by_revision),selected_heatmap_seeds=selected,
              overlapping_policy_edits_during_tests=0,incomplete_test_commands=incomplete,
              note='Within-run descriptive observations, not independent trials; no inference about hidden reasoning.')
(OUT/'plot_data.json').write_text(json.dumps(dict(metadata=metadata,batches=batches,fixed_cases=baseline,
                                                timeline_lanes=lanes,heatmap_values=matrix.tolist()),indent=2)+'\n')
(OUT/'summary.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
