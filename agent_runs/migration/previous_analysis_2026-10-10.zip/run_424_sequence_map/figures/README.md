# Three descriptive figures for the replicate_424 discussion

These figures describe the development of one Obstruction2D control program. They are extracted from the saved transcript, not from new robot evaluations. The dataset was not modified. PNG files are ready for slides; SVG files are editable vector versions.

## Suggested meeting order

1. **Development timeline** (`01_development_timeline.png`). Ask: *What did the coding agent do, and in what order?* Each mark is one completed event of the displayed type. Early custom environment scripts are visually concentrated before repeated editing and testing. Those scripts are a starting point for inspecting information gathering; their presence alone does not establish a world model or model-based reasoning. Background sections are our reading aids, not inferred mental states. The horizontal axis is event order, not minutes or tokens.
2. **Performance on fixed cases** (`02_fixed_cases_performance.png`). Ask: *Did successive programs improve on comparable cases?* Count successes for the same default-reset seeds 0–10. There are matching results at 25 of the 51 saved revisions. Examples: R18 solves 8/11; R26 solves 5/11; R35 solves 10/11 after seed 3 breaks. Gaps remain gaps. These are development cases the agent repeatedly used, so the curve is not a held-out generalization estimate.
3. **Case-by-revision heatmap** (`03_case_outcomes.png`). Ask: *What does an overall score hide?* At R37, seeds 0–10 all pass, but seed 18 fails. Seed 18's observed sequence is fail at R33 → pass at R34 → fail at R37 → pass at R38. This is the strongest bridge from a plot to close reading of the implementation. The ten rows were selected because they occur in the repair narrative; they do not estimate the prevalence of regressions across all possible cases.

If you only have room for two figures, use the fixed-case curve and the heatmap, then show the R37/R38 code difference alongside them.

## A narrow hypothesis to discuss

**Candidate hypothesis:** a repair aimed at one geometric failure can disrupt a condition needed by a previously successful case.

Observed evidence: seed 18 succeeds at R34, fails at R37, and succeeds at R38. The fixed eleven-case score is still perfect at R37. This establishes an observed regression and recovery; it does not identify the causal code change or establish a general tendency of the agent.

Next experiment: replay the same seed using the adjacent saved programs and then change one component at a time. R37 changes both a height tolerance and future-pickup constraints, so comparing R36 and R37 alone cannot distinguish their contributions. Inspect the diffs and transcript first, then construct separate ablations and evaluate on fixed cases plus additional cases the agent did not use in development. No replay or ablation has been run for these figures.

For the decision-making question, add the evidence chain: **observed failure → agent's stated diagnosis, if present → implemented change → subsequent test result**. Compare what the agent said with what the code actually does. The plots locate informative episodes; they do not recover hidden reasoning. No formal ACT*ONOMY labels or model-based/model-free percentages are assigned here.

## How the numbers were obtained

1. Read `../evidence/stream.jsonl`, preserving original line numbers. Keep `item.completed` events so command-start and progress updates are not counted as separate actions. Match starts and completions using both turn number and item ID.
2. Read `../revision_inventory.json` to associate commands with saved policy revisions. Commands that commit and then test are associated with that new revision. Check that no recorded policy edits occur while a harness command is running; none do in this transcript.
3. Identify actual `test_approach.py` invocations. One shell command may invoke the harness several times. Split its output at each `success X / Y` report and match each batch to its invocation and flags in order.
4. Validate each batch: printed episode rows match the reported count and number of successes; seeds match the requested range; specified object counts match the printed counts. Keep `--count` tests separate from default-reset tests. The same seed with a different reset configuration is not treated as the same case.
5. For the fixed-case plot, use a complete recorded batch containing all seeds 0–10; extract exactly those eleven rows even if the batch was larger. Their object-count vector also agrees across matching batches. The bounded harness uses the same default seeded reset and step limit; the later harness adds optional object-count control. These checks support comparability, but are not a fresh verification of identical initial-state geometry.
6. For the heatmap, keep default-reset results for the ten specified seeds at each saved revision. Missing observations remain grey. Repeated observations within a cell are combined when their outcomes agree; conflicting repeats would receive a separate colour. Grey means no qualifying recorded harness result here, not that the agent never inspected that case through another tool.

The timeline's categories are simple observable types, not psychological labels. “Custom environment scripts” are commands containing `from env_client import make_env` and a Python heredoc. “Policy edits” are completed file-change events touching `/sandbox/approach.py`. These lexical rules make the extraction reproducible, but do not replace reading the scripts.

## Counts and limits

- 53 policy-edit events, including the initial program and two edits preceding R01. These are not 53 distinct saved policy revisions.
- 51 saved revisions after the initial program; the revision axis excludes the initial program.
- 77 harness commands contain 130 completed test batches and 744 recorded episode-result rows. These rows include repeated cases and different reset conditions; **744 is not the number of independent trials**.
- 25 revisions have a complete matching eleven-case batch.
- Two initial harness commands have no completed result batch. Three later commands encounter reset-sampling failures; one of those contains a completed earlier batch that is retained. Reset errors are not counted as robot failures.
- The resumed second turn belongs to the same run. It is not a replicate. These figures do not pool other runs, reruns, or reevaluations.

For this meeting, avoid a pooled success percentage across changing test batches, a model-based/model-free pie chart without validated annotations, or significance tests treating code revisions as independent runs. A descriptive single-case analysis is useful here: the aim is to formulate a precise, testable question.

## Files to inspect and reproduce

- `../evidence/stream.jsonl`: original line-numbered source for tool actions and outcomes.
- `../evidence/transcript.md`: readable source, with anchors such as `L378` and `L380` (R37 tests), and `L387` (R38 tests).
- `../revision_inventory.json`: revision-to-commit and evidence mapping.
- `../diffs/` and `../versions/`: implementation changes and saved programs.
- `../harness_versions/`: checks on the evaluation procedure.
- `plot_data.json`: every plotted batch, episode row, source line, timeline lane, and heatmap value. Heatmap rows follow `metadata.selected_heatmap_seeds`; columns are R01–R51; values −1/0/1/2 mean missing/fail/pass/conflicting repeats.
- `summary.json`: extraction counts and incomplete commands.
- `make_figures.py`: complete reproducible extraction and plotting code. Requires Python, NumPy, and Matplotlib.

From the repository root:

```bash
python3 actonomoy/run_424_sequence_map/figures/make_figures.py
```

This regenerates only files in this figures folder and reads the copied evidence. It never executes archived agent commands or robot programs.
