# How to reconstruct this map yourself

The reproducible extraction script is [build_run_424_map.py](../build_run_424_map.py). Its `REVISIONS` list contains the analyst-written descriptions and selected evidence references, so those interpretations are separate from mechanically recovered commits, diffs and test outputs.

## The procedure

1. Read the run's `stream.jsonl` and list its saved Git history. `git log --reverse --format='%h %s' -- approach.py` gives the policy-changing commits in order.
2. Match each commit subject to an actual `git commit` command in a completed transcript event. Verify that the commit exists in Git; a command containing the word `commit` is insufficient. L528 is the useful negative example: it attempts a commit, but no commit was created.
3. Exclude the initial baseline from the subsequent-revision count. Keep it as the initial program. Include all later policy-changing commits regardless of whether the tests succeed.
4. Use `git show COMMIT:approach.py` and `git diff PARENT COMMIT -- approach.py` to obtain exact saved programs and differences. Use the actual Git parent, since setup or test-harness commits can intervene between policy changes.
5. Read backward to the previous policy commit and relevant earlier feedback. Find failure reports, diagnostic probes and statements preceding the edit. A nearby event is context; proximity alone does not establish the agent's motivation.
6. Read forward from the current commit until the next policy edit or the current turn ends. Record test batches and additional checks in that interval. Preserve command flags and individual episode results; do not silently pool batches.
7. Write a plain sequence: **observed problem → investigation, if visible → actual edit → recorded result**. Include “not visible” where evidence is missing. Preserve failures and reversals.
8. Separately scan messages, probes and harness changes for decisions that do not center on a policy edit. This produces the examples in `other_sequences.md`.

## Checks that matter

- Count completed events once. Started/updated records remain in the exact JSONL but are not additional actions. Item IDs can repeat across turns, so the original source line is retained as the local unique identifier.
- All 52 policy-changing commits match one completed commit-command event. All 53 main-stream policy file-change events are accounted for: the baseline, two edits before R01, and one edit per remaining revision.
- There are 56 saved Git commits in total. Two setup commits and two harness-only commits do not count as policy revisions.
- The initial harness was later changed to enforce the step limit at R01. Pinned-count support is another later harness change. These prevent treating every result as an identical evaluation protocol.
- R32 has no new rollout report before its turn's handoff. L335 later probes its unchanged policy after continuation; the map records this with R33.
- SHA256 checks identify exact repeated policy contents. Revisiting code within a run is a real development event; duplicate archive exports would be a separate issue.
- `before.py` conceptually means the saved parent state, not the first code the agent ever wrote. Commit snapshots do not guarantee recovery of every transient edit.
- The final working policy matches Git HEAD. This does not establish that every historical outcome can be replayed in the current environment.

## Reproduction and scope

Run `python3 actonomoy/build_run_424_map.py` from the repository to reproduce generated evidence and inventories. The script reads the source path from the existing seed-18 provenance file, uses read-only Git commands and writes only the separate sequence-map folder. It refuses to overwrite generated files whose contents differ. The README, pattern examples and hypothesis worksheet are separately authored explanatory files.

This reconstruction covers the main stream and saved Git history. Backend sessions could contain additional details, so “all” here means all saved policy revisions and all main-stream events under this stated scope. No historical agent instructions were adopted as instructions for the analysis.
