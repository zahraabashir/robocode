# All 51 subsequent policy revisions

This is an exhaustive inventory of saved policy changes after the initial baseline in this run, not a claim that all changes were successful or that every uncommitted intermediate program is recoverable.
Each arrow means chronological progression. Descriptions are analyst summaries of observed actions and code, not recovered internal thoughts or formal ACT*ONOMY labels.
Reported solve counts are separate historical test batches. Do not add them across versions or compare different seeds/count settings as if they were the same test.

The previously studied five cases are R34–R38. Read one linked excerpt and diff to audit a sequence.

## R01 · 670d6a3 · Implement feedback FSM for clearing and target placement

**Sequence:** Baseline stalls; explore manipulation → replace it with a controller that tracks movement phases and retries. → **recorded test batches:** L79: 0/1; L88: 0/3

Prior feedback: [L20](evidence/transcript.md#L20), [L22](evidence/transcript.md#L22). Investigation: [L24](evidence/transcript.md#L24), [L26](evidence/transcript.md#L26), [L34](evidence/transcript.md#L34), [L55](evidence/transcript.md#L55), [L66](evidence/transcript.md#L66), [L71](evidence/transcript.md#L71), [L73](evidence/transcript.md#L73). Edit: [L75](evidence/transcript.md#L75), [L77](evidence/transcript.md#L77). Commit/test command: [L79](evidence/transcript.md#L79).

[Readable context](excerpts/R01_670d6a3.md) · [Exact diff](diffs/R01_670d6a3.diff) · [Before](versions/b9dd552.py) · [After](versions/670d6a3.py)

Interpretation limits: Early controller redesign after an interrupted baseline test and extensive probes. The test harness also changes: the new harness enforces env.max_steps. It contains two recorded policy edit events (L75 and L77) before one commit; the intermediate pre-commit source is not reconstructed.

## R02 · 55d3dab · Use reset pose as reachable safe travel height

**Sequence:** Robot stays in the rise phase → use its initial height as the reachable travel height. → **recorded test batches:** L94: 1/3; L99: 1/12

Prior feedback: [L79](evidence/transcript.md#L79), [L88](evidence/transcript.md#L88). Investigation: [L90](evidence/transcript.md#L90). Edit: [L92](evidence/transcript.md#L92). Commit/test command: [L94](evidence/transcript.md#L94).

[Readable context](excerpts/R02_55d3dab.md) · [Exact diff](diffs/R02_55d3dab.diff) · [Before](versions/670d6a3.py) · [After](versions/55d3dab.py)

## R03 · 98c6f07 · Park all movable objects tallest-first before final placement

**Sequence:** Multi-object cases still fail → reorder rectangles tallest first and include an initial target-clearing pass. → **recorded test batches:** L106: 0/4

Prior feedback: [L94](evidence/transcript.md#L94), [L99](evidence/transcript.md#L99). Investigation: [L102](evidence/transcript.md#L102). Edit: [L104](evidence/transcript.md#L104). Commit/test command: [L106](evidence/transcript.md#L106).

[Readable context](excerpts/R03_98c6f07.md) · [Exact diff](diffs/R03_98c6f07.diff) · [Before](versions/55d3dab.py) · [After](versions/98c6f07.py)

## R04 · 6d93a7d · Exclude static surface and park cleared objects vertically

**Sequence:** Printed task list includes the static surface and motion stalls → filter static objects and park vertically in place. → **recorded test batches:** L112: 0/4

Prior feedback: [L106](evidence/transcript.md#L106). Investigation: [L108](evidence/transcript.md#L108). Edit: [L110](evidence/transcript.md#L110). Commit/test command: [L112](evidence/transcript.md#L112).

[Readable context](excerpts/R04_6d93a7d.md) · [Exact diff](diffs/R04_6d93a7d.diff) · [Before](versions/98c6f07.py) · [After](versions/6d93a7d.py)

Interpretation limits: Multiple code decisions change together. Outcome attribution to an individual component requires further checking.

## R05 · e727013 · Keep vacuum off during horizontal transit

**Sequence:** Target moves while the robot travels toward another object → turn vacuum off during horizontal alignment. → **recorded test batches:** L118: 0/4

Prior feedback: [L112](evidence/transcript.md#L112). Investigation: [L114](evidence/transcript.md#L114). Edit: [L116](evidence/transcript.md#L116). Commit/test command: [L118](evidence/transcript.md#L118).

[Readable context](excerpts/R05_e727013.md) · [Exact diff](diffs/R05_e727013.diff) · [Before](versions/6d93a7d.py) · [After](versions/e727013.py)

## R06 · 5a9cda5 · Park cleared objects low enough for later regrasp

**Sequence:** Objects remain high and the target cannot be regrasped → stop preliminary lifts at a lower parking height. → **recorded test batches:** L124: 0/4

Prior feedback: [L118](evidence/transcript.md#L118). Investigation: [L120](evidence/transcript.md#L120). Edit: [L122](evidence/transcript.md#L122). Commit/test command: [L124](evidence/transcript.md#L124).

[Readable context](excerpts/R06_5a9cda5.md) · [Exact diff](diffs/R06_5a9cda5.diff) · [Before](versions/e727013.py) · [After](versions/5a9cda5.py)

## R07 · f214f7d · Park obstructions laterally away from target surface

**Sequence:** Controller finishes but placement fails → move obstructions laterally away from the surface. → **recorded test batches:** L130: 1/1; L132: 1/10

Prior feedback: [L124](evidence/transcript.md#L124). Investigation: [L126](evidence/transcript.md#L126). Edit: [L128](evidence/transcript.md#L128). Commit/test command: [L130](evidence/transcript.md#L130).

[Readable context](excerpts/R07_f214f7d.md) · [Exact diff](diffs/R07_f214f7d.diff) · [Before](versions/5a9cda5.py) · [After](versions/f214f7d.py)

## R08 · dd0457e · Only pre-park target when it blocks obstacle access

**Sequence:** Broader tests mostly fail → temporarily move the target only when the geometry is crowded. → **recorded test batches:** L144: 0/4

Prior feedback: [L132](evidence/transcript.md#L132). Investigation: [L136](evidence/transcript.md#L136), [L138](evidence/transcript.md#L138), [L140](evidence/transcript.md#L140). Edit: [L142](evidence/transcript.md#L142). Commit/test command: [L144](evidence/transcript.md#L144).

[Readable context](excerpts/R08_dd0457e.md) · [Exact diff](diffs/R08_dd0457e.diff) · [Before](versions/f214f7d.py) · [After](versions/dd0457e.py)

## R09 · 3f73fd4 · Fix moving-goal bug in obstruction carry phase

**Sequence:** Failure persists with a moving obstruction destination → calculate that destination from the initial object position. → **recorded test batches:** L150: 0/1; L163: 0/1, 0/1, 0/1

Prior feedback: [L144](evidence/transcript.md#L144). Investigation: [L146](evidence/transcript.md#L146). Edit: [L148](evidence/transcript.md#L148). Commit/test command: [L150](evidence/transcript.md#L150).

[Readable context](excerpts/R09_3f73fd4.md) · [Exact diff](diffs/R09_3f73fd4.diff) · [Before](versions/dd0457e.py) · [After](versions/3f73fd4.py)

## R10 · 735b56a · Use lower carry height to match successful placement trajectory

**Sequence:** Program placement fails despite a successful hand-scripted placement probe → lower the carry-height threshold. → **recorded test batches:** L177: 0/1

Prior feedback: [L150](evidence/transcript.md#L150), [L163](evidence/transcript.md#L163). Investigation: [L152](evidence/transcript.md#L152), [L154](evidence/transcript.md#L154), [L157](evidence/transcript.md#L157), [L165](evidence/transcript.md#L165), [L167](evidence/transcript.md#L167), [L169](evidence/transcript.md#L169), [L171](evidence/transcript.md#L171), [L173](evidence/transcript.md#L173). Edit: [L175](evidence/transcript.md#L175). Commit/test command: [L177](evidence/transcript.md#L177).

[Readable context](excerpts/R10_735b56a.md) · [Exact diff](diffs/R10_735b56a.diff) · [Before](versions/3f73fd4.py) · [After](versions/735b56a.py)

## R11 · b15ba76 · Bias final placement slightly inside successful support region

**Sequence:** Lower carry height does not solve seed 1 → add a small horizontal offset to final placement. → **recorded test batches:** L181: 1/1; L183: 0/1, 0/1, 1/1, 0/1

Prior feedback: [L177](evidence/transcript.md#L177). Investigation: none recorded in this local interval. Edit: [L179](evidence/transcript.md#L179). Commit/test command: [L181](evidence/transcript.md#L181).

[Readable context](excerpts/R11_b15ba76.md) · [Exact diff](diffs/R11_b15ba76.diff) · [Before](versions/735b56a.py) · [After](versions/b15ba76.py)

## R12 · af4477f · Use fine vertical steps so vacuum reaches contact

**Sequence:** Several grasp cases fail; a fine-step probe lifts them → reduce downward steps from 0.05 to 0.01. → **recorded test batches:** L193: 1/4

Prior feedback: [L183](evidence/transcript.md#L183). Investigation: [L185](evidence/transcript.md#L185), [L187](evidence/transcript.md#L187), [L189](evidence/transcript.md#L189). Edit: [L191](evidence/transcript.md#L191). Commit/test command: [L193](evidence/transcript.md#L193).

[Readable context](excerpts/R12_af4477f.md) · [Exact diff](diffs/R12_af4477f.diff) · [Before](versions/b15ba76.py) · [After](versions/af4477f.py)

## R13 · 9c6bdf4 · Avoid overshooting ceiling during retreat

**Sequence:** Robot stalls in retreat below its requested height → cap the upward step at the remaining height. → **recorded test batches:** L201: 2/5

Prior feedback: [L193](evidence/transcript.md#L193). Investigation: [L195](evidence/transcript.md#L195), [L197](evidence/transcript.md#L197). Edit: [L199](evidence/transcript.md#L199). Commit/test command: [L201](evidence/transcript.md#L201).

[Readable context](excerpts/R13_9c6bdf4.md) · [Exact diff](diffs/R13_9c6bdf4.diff) · [Before](versions/af4477f.py) · [After](versions/9c6bdf4.py)

## R14 · 4f80855 · Park blockers away from target and handle travel bounds

**Sequence:** Target access and boundary cases remain → change parking direction and detect stalled horizontal carrying. → **recorded test batches:** L207: 1/5

Prior feedback: [L201](evidence/transcript.md#L201). Investigation: [L203](evidence/transcript.md#L203). Edit: [L205](evidence/transcript.md#L205). Commit/test command: [L207](evidence/transcript.md#L207).

[Readable context](excerpts/R14_4f80855.md) · [Exact diff](diffs/R14_4f80855.diff) · [Before](versions/9c6bdf4.py) · [After](versions/4f80855.py)

Interpretation limits: Multiple code decisions change together. Outcome attribution to an individual component requires further checking.

## R15 · 2d184c4 · Vertically separate parked blockers and recover at walls

**Sequence:** Failures remain after new parking rule → vary parking heights and add stalled-alignment recovery. → **recorded test batches:** L213: 1/5

Prior feedback: [L207](evidence/transcript.md#L207). Investigation: [L209](evidence/transcript.md#L209). Edit: [L211](evidence/transcript.md#L211). Commit/test command: [L213](evidence/transcript.md#L213).

[Readable context](excerpts/R15_2d184c4.md) · [Exact diff](diffs/R15_2d184c4.diff) · [Before](versions/4f80855.py) · [After](versions/2d184c4.py)

Interpretation limits: Multiple code decisions change together. Outcome attribution to an individual component requires further checking.

## R16 · 0c006f7 · Park blockers far outside surface at low clearance height

**Sequence:** Objects still obstruct target movement → return to lower parking and move blockers farther away from the surface. → **recorded test batches:** L221: 3/5; L223: 2/6, 1/1, 1/1, 1/1

Prior feedback: [L213](evidence/transcript.md#L213). Investigation: [L215](evidence/transcript.md#L215), [L217](evidence/transcript.md#L217). Edit: [L219](evidence/transcript.md#L219). Commit/test command: [L221](evidence/transcript.md#L221).

[Readable context](excerpts/R16_0c006f7.md) · [Exact diff](diffs/R16_0c006f7.diff) · [Before](versions/2d184c4.py) · [After](versions/0c006f7.py)

## R17 · adf84ae · Add edge grasps and compensate carried-object offset

**Sequence:** Several target pickups remain blocked → expand grasp offsets and compensate for the object-to-gripper offset. → **recorded test batches:** L229: 5/11

Prior feedback: [L221](evidence/transcript.md#L221), [L223](evidence/transcript.md#L223). Investigation: [L225](evidence/transcript.md#L225). Edit: [L227](evidence/transcript.md#L227). Commit/test command: [L229](evidence/transcript.md#L229).

[Readable context](excerpts/R17_adf84ae.md) · [Exact diff](diffs/R17_adf84ae.diff) · [Before](versions/0c006f7.py) · [After](versions/adf84ae.py)

Interpretation limits: Multiple code decisions change together. Outcome attribution to an individual component requires further checking.

## R18 · b7ccec6 · Allocate geometry-scored parking slots for blockers

**Sequence:** Multi-obstacle parking failures persist → rank candidate parking positions by geometric clearance. → **recorded test batches:** L236: 8/11

Prior feedback: [L229](evidence/transcript.md#L229). Investigation: [L231](evidence/transcript.md#L231). Edit: [L234](evidence/transcript.md#L234). Commit/test command: [L236](evidence/transcript.md#L236).

[Readable context](excerpts/R18_b7ccec6.md) · [Exact diff](diffs/R18_b7ccec6.diff) · [Before](versions/adf84ae.py) · [After](versions/b7ccec6.py)

## R19 · 0f0c2ee · Reserve a remote slot for temporarily parked target

**Sequence:** Three regression cases still fail → reserve a remote parking position for the temporarily moved target. → **recorded test batches:** L242: 10/11

Prior feedback: [L236](evidence/transcript.md#L236). Investigation: [L238](evidence/transcript.md#L238). Edit: [L240](evidence/transcript.md#L240). Commit/test command: [L242](evidence/transcript.md#L242).

[Readable context](excerpts/R19_0f0c2ee.md) · [Exact diff](diffs/R19_0f0c2ee.diff) · [Before](versions/b7ccec6.py) · [After](versions/0f0c2ee.py)

## R20 · 71c469c · Lift final target above all parked blockers

**Sequence:** Seed 3 stalls while carrying the final target → increase final target carry height. → **recorded test batches:** L248: 10/11

Prior feedback: [L242](evidence/transcript.md#L242). Investigation: [L244](evidence/transcript.md#L244). Edit: [L246](evidence/transcript.md#L246). Commit/test command: [L248](evidence/transcript.md#L248).

[Readable context](excerpts/R20_71c469c.md) · [Exact diff](diffs/R20_71c469c.diff) · [Before](versions/0f0c2ee.py) · [After](versions/71c469c.py)

## R21 · 2185ba3 · Keep parking slots away from side-wall dead zones

**Sequence:** Seed 5 fails after earlier fixes → move candidate parking positions away from side walls. → **recorded test batches:** L254: 10/11

Prior feedback: [L248](evidence/transcript.md#L248). Investigation: [L250](evidence/transcript.md#L250). Edit: [L252](evidence/transcript.md#L252). Commit/test command: [L254](evidence/transcript.md#L254).

[Readable context](excerpts/R21_2185ba3.md) · [Exact diff](diffs/R21_2185ba3.diff) · [Before](versions/71c469c.py) · [After](versions/2185ba3.py)

## R22 · 8e66f4e · Cap verification lift at reachable ceiling

**Sequence:** Seed 5 still stalls in lift → cap upward movement at the reachable ceiling. → **recorded test batches:** L260: 1/1; L263: 18/20

Prior feedback: [L254](evidence/transcript.md#L254). Investigation: [L256](evidence/transcript.md#L256). Edit: [L258](evidence/transcript.md#L258). Commit/test command: [L260](evidence/transcript.md#L260).

[Readable context](excerpts/R22_8e66f4e.md) · [Exact diff](diffs/R22_8e66f4e.diff) · [Before](versions/2185ba3.py) · [After](versions/8e66f4e.py)

## R23 · 3098aab · Raise temporary target and maximize final carry clearance

**Sequence:** A broader sweep finds seeds 18 and 22 failing → raise temporary target parking and final carry height. → **recorded test batches:** L271: 0/1, 0/1

Prior feedback: [L263](evidence/transcript.md#L263). Investigation: [L265](evidence/transcript.md#L265), [L267](evidence/transcript.md#L267). Edit: [L269](evidence/transcript.md#L269). Commit/test command: [L271](evidence/transcript.md#L271).

[Readable context](excerpts/R23_3098aab.md) · [Exact diff](diffs/R23_3098aab.diff) · [Before](versions/8e66f4e.py) · [After](versions/3098aab.py)

Interpretation limits: Multiple code decisions change together. Outcome attribution to an individual component requires further checking.

## R24 · 5075837 · Park crowded target outward and lower cleared blockers

**Sequence:** Both targeted cases still fail → choose an outward target slot and lower blocker parking. → **recorded test batches:** L277: 0/1, 1/1

Prior feedback: [L271](evidence/transcript.md#L271). Investigation: [L273](evidence/transcript.md#L273). Edit: [L275](evidence/transcript.md#L275). Commit/test command: [L277](evidence/transcript.md#L277).

[Readable context](excerpts/R24_5075837.md) · [Exact diff](diffs/R24_5075837.diff) · [Before](versions/3098aab.py) · [After](versions/5075837.py)

Interpretation limits: Multiple code decisions change together. Outcome attribution to an individual component requires further checking.

## R25 · 0605fd3 · Route blockers outward without crossing the surface cluster

**Sequence:** Seed 18 remains unresolved → restrict blocker parking to the same side of the surface. → **recorded test batches:** L283: 0/1

Prior feedback: [L277](evidence/transcript.md#L277). Investigation: [L279](evidence/transcript.md#L279). Edit: [L281](evidence/transcript.md#L281). Commit/test command: [L283](evidence/transcript.md#L283).

[Readable context](excerpts/R25_0605fd3.md) · [Exact diff](diffs/R25_0605fd3.diff) · [Before](versions/5075837.py) · [After](versions/0605fd3.py)

## R26 · f064af0 · Carry blockers high then lower them into parking slots

**Sequence:** Seed 18 remains unresolved → carry blockers higher and add a separate lowering phase. → **recorded test batches:** L289: 0/1, 5/11

Prior feedback: [L283](evidence/transcript.md#L283). Investigation: [L285](evidence/transcript.md#L285). Edit: [L287](evidence/transcript.md#L287). Commit/test command: [L289](evidence/transcript.md#L289).

[Readable context](excerpts/R26_f064af0.md) · [Exact diff](diffs/R26_f064af0.diff) · [Before](versions/0605fd3.py) · [After](versions/f064af0.py)

## R27 · a4cb1db · Accept maximum reachable blocker carry height

**Sequence:** Seed 18 and six baseline cases fail → allow a blocker lift to finish at the reachable ceiling. → **recorded test batches:** L293: 0/1, 5/11

Prior feedback: [L289](evidence/transcript.md#L289). Investigation: none recorded in this local interval. Edit: [L291](evidence/transcript.md#L291). Commit/test command: [L293](evidence/transcript.md#L293).

[Readable context](excerpts/R27_a4cb1db.md) · [Exact diff](diffs/R27_a4cb1db.diff) · [Before](versions/f064af0.py) · [After](versions/a4cb1db.py)

## R28 · 13fcd58 · Restore reliable low blocker parking behavior

**Sequence:** The broad failures persist → undo the high-carry/lowering changes and restore low parking. → **recorded test batches:** L297: 8/11

Prior feedback: [L293](evidence/transcript.md#L293). Investigation: none recorded in this local interval. Edit: [L295](evidence/transcript.md#L295). Commit/test command: [L297](evidence/transcript.md#L297).

[Readable context](excerpts/R28_13fcd58.md) · [Exact diff](diffs/R28_13fcd58.diff) · [Before](versions/a4cb1db.py) · [After](versions/13fcd58.py)

Interpretation limits: Restores part of an earlier rule. A partial reversal is not necessarily a full Git revert or an exact return to an earlier complete program.

## R29 · 04141a4 · Choose globally clear parking slots over directional routing

**Sequence:** Three baseline failures remain → remove the same-side parking restriction. → **recorded test batches:** L301: 10/11

Prior feedback: [L297](evidence/transcript.md#L297). Investigation: none recorded in this local interval. Edit: [L299](evidence/transcript.md#L299). Commit/test command: [L301](evidence/transcript.md#L301).

[Readable context](excerpts/R29_04141a4.md) · [Exact diff](diffs/R29_04141a4.diff) · [Before](versions/13fcd58.py) · [After](versions/04141a4.py)

Interpretation limits: Restores part of an earlier rule. A partial reversal is not necessarily a full Git revert or an exact return to an earlier complete program.

## R30 · 3f93ca0 · Use globally safest temporary target slot

**Sequence:** Seed 10 remains unresolved → remove the outward-only target parking rule. → **recorded test batches:** L307: 1/1, 0/1; L311: 26/30

Prior feedback: [L301](evidence/transcript.md#L301). Investigation: [L303](evidence/transcript.md#L303). Edit: [L305](evidence/transcript.md#L305). Commit/test command: [L307](evidence/transcript.md#L307).

[Readable context](excerpts/R30_3f93ca0.md) · [Exact diff](diffs/R30_3f93ca0.diff) · [Before](versions/04141a4.py) · [After](versions/3f93ca0.py)

Interpretation limits: Restores part of an earlier rule. A partial reversal is not necessarily a full Git revert or an exact return to an earlier complete program.

## R31 · 990576d · Use denser nonoverlapping parking allocation

**Sequence:** Several clustered cases fail → reduce the spacing margin between parked objects. → **recorded test batches:** L317: 0/1, 0/1, 0/1, 0/1

Prior feedback: [L307](evidence/transcript.md#L307), [L311](evidence/transcript.md#L311). Investigation: [L313](evidence/transcript.md#L313). Edit: [L315](evidence/transcript.md#L315). Commit/test command: [L317](evidence/transcript.md#L317).

[Readable context](excerpts/R31_990576d.md) · [Exact diff](diffs/R31_990576d.diff) · [Before](versions/3f93ca0.py) · [After](versions/990576d.py)

## R32 · a11bd5f · Restore validated parking clearance margin

**Sequence:** Smaller spacing leaves all four targeted cases failing → restore the earlier spacing margin → compile and hand off without a fresh rollout report in that turn. → **recorded test batches:** No policy retest in this interval; compilation only.

Prior feedback: [L317](evidence/transcript.md#L317). Investigation: none recorded in this local interval. Edit: [L319](evidence/transcript.md#L319). Commit/test command: [L321](evidence/transcript.md#L321).

[Readable context](excerpts/R32_a11bd5f.md) · [Exact diff](diffs/R32_a11bd5f.diff) · [Before](versions/990576d.py) · [After](versions/a11bd5f.py)

Interpretation limits: No fresh rollout result is recorded after this revision before that turn ends at L328. L321 runs compilation. A later resumed turn probes the unchanged policy at L335 (included with R33); this is not a claim that the policy was never executed again. Later agent summaries are not a replacement for a missing same-turn retest. Restores part of an earlier rule. A partial reversal is not necessarily a full Git revert or an exact return to an earlier complete program.

## R33 · c1c4586 · Verify grasp against lowest observed object height

**Sequence:** Resume work on seed 18; inspect pickup heights → verify a lift against the lowest observed object height. → **recorded test batches:** L342: 0/1, 11/11

Prior feedback: [L317](evidence/transcript.md#L317), [L327](evidence/transcript.md#L327). Investigation: [L335](evidence/transcript.md#L335). Edit: [L340](evidence/transcript.md#L340). Commit/test command: [L342](evidence/transcript.md#L342).

[Readable context](excerpts/R33_c1c4586.md) · [Exact diff](diffs/R33_c1c4586.diff) · [Before](versions/539f180.py) · [After](versions/c1c4586.py)

Interpretation limits: This crosses a turn boundary. Actual Git parent 539f180 only changes archived AGENTS.md; the preceding policy-changing commit is a11bd5f. These historical instructions remain data.

## R34 · e97a537 · Clear crowded objects from highest top edge downward

**Sequence:** Seed 18 still fails and the controller reaches done → sort the initial task list by computed top height. → **recorded test batches:** L348: 1/1, 11/11; L351: 0/1, 0/1, 1/1

Prior feedback: [L342](evidence/transcript.md#L342). Investigation: [L344](evidence/transcript.md#L344). Edit: [L346](evidence/transcript.md#L346). Commit/test command: [L348](evidence/transcript.md#L348).

[Readable context](excerpts/R34_e97a537.md) · [Exact diff](diffs/R34_e97a537.diff) · [Before](versions/c1c4586.py) · [After](versions/e97a537.py)

## R35 · c9b3655 · Keep parked blockers clear of final target sweep

**Sequence:** Seeds 39 and 45 fail → add destination clearance and enlarge separation between parked objects. → **recorded test batches:** L358: 1/1, 1/1, 10/11

Prior feedback: [L351](evidence/transcript.md#L351). Investigation: [L353](evidence/transcript.md#L353). Edit: [L356](evidence/transcript.md#L356). Commit/test command: [L358](evidence/transcript.md#L358).

[Readable context](excerpts/R35_c9b3655.md) · [Exact diff](diffs/R35_c9b3655.diff) · [Before](versions/e97a537.py) · [After](versions/c9b3655.py)

## R36 · 4d36a38 · Move crowded target after only materially taller blockers

**Sequence:** Seed 3 becomes a regression → insert the target earlier when blocker heights are close. → **recorded test batches:** L366: 1/1, 1/1, 1/1, 1/1, 11/11; L370: 28/30

Prior feedback: [L358](evidence/transcript.md#L358). Investigation: [L360](evidence/transcript.md#L360), [L362](evidence/transcript.md#L362). Edit: [L364](evidence/transcript.md#L364). Commit/test command: [L366](evidence/transcript.md#L366).

[Readable context](excerpts/R36_4d36a38.md) · [Exact diff](diffs/R36_4d36a38.diff) · [Before](versions/c9b3655.py) · [After](versions/4d36a38.py)

## R37 · be6feb6 · Protect future pickups when assigning parking slots

**Sequence:** Seeds 15 and 26 fail → widen the height tolerance AND reject parking slots near future pickups. → **recorded test batches:** L378: 1/1, 1/1, 11/11; L380: 24/25

Prior feedback: [L370](evidence/transcript.md#L370). Investigation: [L373](evidence/transcript.md#L373). Edit: [L376](evidence/transcript.md#L376). Commit/test command: [L378](evidence/transcript.md#L378).

[Readable context](excerpts/R37_be6feb6.md) · [Exact diff](diffs/R37_be6feb6.diff) · [Before](versions/4d36a38.py) · [After](versions/be6feb6.py)

Interpretation limits: Multiple code decisions change together. Outcome attribution to an individual component requires further checking.

## R38 · 616a82f · Prioritize physically overlapping taller blockers

**Sequence:** Seed 18 breaks again → include geometric overlap in the target-ordering criterion. → **recorded test batches:** L387: 1/1, 1/1, 11/11; L389: 25/26

Prior feedback: [L380](evidence/transcript.md#L380). Investigation: [L382](evidence/transcript.md#L382). Edit: [L385](evidence/transcript.md#L385). Commit/test command: [L387](evidence/transcript.md#L387).

[Readable context](excerpts/R38_616a82f.md) · [Exact diff](diffs/R38_616a82f.diff) · [Before](versions/be6feb6.py) · [After](versions/616a82f.py)

## R39 · dafcc2f · Allocate outer parking slots before inner ones

**Sequence:** Seed 59 fails → allocate farther-from-surface parking positions before inner positions. → **recorded test batches:** L396: 1/1, 1/1, 1/1, 11/11; L401: 29/30; L411: 3/5

Prior feedback: [L389](evidence/transcript.md#L389). Investigation: [L391](evidence/transcript.md#L391). Edit: [L394](evidence/transcript.md#L394). Commit/test command: [L396](evidence/transcript.md#L396).

[Readable context](excerpts/R39_dafcc2f.md) · [Exact diff](diffs/R39_dafcc2f.diff) · [Before](versions/616a82f.py) · [After](versions/dafcc2f.py)

## R40 · 0e14ec7 · Choose least-conflicting fallback parking slots

**Sequence:** Pinned count-3 tests fail on seeds 1 and 3 → densify the parking grid and score fallback constraint violations. → **recorded test batches:** L417: 1/1, 1/1, 4/5

Prior feedback: [L411](evidence/transcript.md#L411). Investigation: [L413](evidence/transcript.md#L413). Edit: [L415](evidence/transcript.md#L415). Commit/test command: [L417](evidence/transcript.md#L417).

[Readable context](excerpts/R40_0e14ec7.md) · [Exact diff](diffs/R40_0e14ec7.diff) · [Before](versions/678059d.py) · [After](versions/0e14ec7.py)

Interpretation limits: Multiple code decisions change together. Outcome attribution to an individual component requires further checking.

## R41 · f87f63f · Increase clearance around future pickup columns

**Sequence:** Count-3 seed 4 now fails → increase clearance around future pickup locations. → **recorded test batches:** L423: 1/1, 11/11; L426: 1/5

Prior feedback: [L417](evidence/transcript.md#L417). Investigation: [L419](evidence/transcript.md#L419). Edit: [L421](evidence/transcript.md#L421). Commit/test command: [L423](evidence/transcript.md#L423).

[Readable context](excerpts/R41_f87f63f.md) · [Exact diff](diffs/R41_f87f63f.diff) · [Before](versions/0e14ec7.py) · [After](versions/f87f63f.py)

## R42 · 6fc104f · Only relocate objects blocking the final placement footprint

**Sequence:** Count-4 testing fails on four of five seeds → only relocate objects near the final placement footprint. → **recorded test batches:** L437: 3/5, 10/11

Prior feedback: [L426](evidence/transcript.md#L426). Investigation: [L428](evidence/transcript.md#L428), [L430](evidence/transcript.md#L430), [L432](evidence/transcript.md#L432). Edit: [L435](evidence/transcript.md#L435). Commit/test command: [L437](evidence/transcript.md#L437).

[Readable context](excerpts/R42_6fc104f.md) · [Exact diff](diffs/R42_6fc104f.diff) · [Before](versions/f87f63f.py) · [After](versions/6fc104f.py)

Interpretation limits: L426 also reports a count-5 environment reset error. That is not evidence of robot-policy failure at count 5.

## R43 · c91cb8e · Include blockers near the placement sweep envelope

**Sequence:** Filtering leaves baseline seed 6 and count-4 cases failing → widen the footprint used to select blockers. → **recorded test batches:** L441: 1/1, 0/1, 1/1

Prior feedback: [L437](evidence/transcript.md#L437). Investigation: none recorded in this local interval. Edit: [L439](evidence/transcript.md#L439). Commit/test command: [L441](evidence/transcript.md#L441).

[Readable context](excerpts/R43_c91cb8e.md) · [Exact diff](diffs/R43_c91cb8e.diff) · [Before](versions/6fc104f.py) · [After](versions/c91cb8e.py)

## R44 · bb1c5eb · Increase clearance from the final lowering corridor

**Sequence:** Count-4 seed 1 still fails → enlarge the clearance around the final lowering location. → **recorded test batches:** L447: 1/1, 5/5, 11/11; L451: 24/25

Prior feedback: [L441](evidence/transcript.md#L441). Investigation: [L443](evidence/transcript.md#L443). Edit: [L445](evidence/transcript.md#L445). Commit/test command: [L447](evidence/transcript.md#L447).

[Readable context](excerpts/R44_bb1c5eb.md) · [Exact diff](diffs/R44_bb1c5eb.diff) · [Before](versions/c91cb8e.py) · [After](versions/bb1c5eb.py)

## R45 · 20d09c8 · Stack blockers when no safe horizontal slot exists

**Sequence:** Seed 93 fails with crowded horizontal parking → add a vertical stacking fallback. → **recorded test batches:** L458: 1/1, 3/5, 11/11

Prior feedback: [L451](evidence/transcript.md#L451). Investigation: [L453](evidence/transcript.md#L453). Edit: [L456](evidence/transcript.md#L456). Commit/test command: [L458](evidence/transcript.md#L458).

[Readable context](excerpts/R45_20d09c8.md) · [Exact diff](diffs/R45_20d09c8.diff) · [Before](versions/bb1c5eb.py) · [After](versions/20d09c8.py)

## R46 · 5210b1a · Stack only outside target transit corridor

**Sequence:** Stacking fixes seed 93 but breaks count-4 cases → restrict stacking to outer columns and small blocker sets. → **recorded test batches:** L464: 1/1, 5/5, 11/11; L469: 10/10, 7/10

Prior feedback: [L458](evidence/transcript.md#L458). Investigation: [L460](evidence/transcript.md#L460). Edit: [L462](evidence/transcript.md#L462). Commit/test command: [L464](evidence/transcript.md#L464).

[Readable context](excerpts/R46_5210b1a.md) · [Exact diff](diffs/R46_5210b1a.diff) · [Before](versions/20d09c8.py) · [After](versions/5210b1a.py)

Interpretation limits: Multiple code decisions change together. Outcome attribution to an individual component requires further checking.

## R47 · 4868fc2 · Shorten recovery lift after failed grasps

**Sequence:** New count-4 failures appear → shorten the verification/recovery lift when no attachment is detected. → **recorded test batches:** L475: 0/1, 11/11

Prior feedback: [L469](evidence/transcript.md#L469). Investigation: [L471](evidence/transcript.md#L471). Edit: [L473](evidence/transcript.md#L473). Commit/test command: [L475](evidence/transcript.md#L475).

[Readable context](excerpts/R47_4868fc2.md) · [Exact diff](diffs/R47_4868fc2.diff) · [Before](versions/5210b1a.py) · [After](versions/4868fc2.py)

## R48 · 7cfa55b · Add tolerance to failed-grasp recovery height

**Sequence:** Count-4 seed 5 still fails → add a tolerance to the lift-height stopping condition. → **recorded test batches:** L481: 0/1, 3/3

Prior feedback: [L475](evidence/transcript.md#L475). Investigation: [L477](evidence/transcript.md#L477). Edit: [L479](evidence/transcript.md#L479). Commit/test command: [L481](evidence/transcript.md#L481).

[Readable context](excerpts/R48_7cfa55b.md) · [Exact diff](diffs/R48_7cfa55b.diff) · [Before](versions/4868fc2.py) · [After](versions/7cfa55b.py)

## R49 · af3dcdd · Recover when verification lift is collision-blocked

**Sequence:** Seed 5 remains stuck in lift → detect vertical stalls and enter recovery. → **recorded test batches:** L489: 1/1, 5/5; L491: 1/1; L493: 9/10

Prior feedback: [L481](evidence/transcript.md#L481). Investigation: [L483](evidence/transcript.md#L483), [L485](evidence/transcript.md#L485). Edit: [L487](evidence/transcript.md#L487). Commit/test command: [L489](evidence/transcript.md#L489).

[Readable context](excerpts/R49_af3dcdd.md) · [Exact diff](diffs/R49_af3dcdd.diff) · [Before](versions/7cfa55b.py) · [After](versions/af3dcdd.py)

## R50 · 05d0971 · Add boundary columns for dense blocker parking

**Sequence:** Count-4 seed 7 remains unresolved → add parking candidates near both boundaries. → **recorded test batches:** L500: 1/1, 1/1, 11/11; L502: 10/10; L509: 25/25; L511: 24/25

Prior feedback: [L493](evidence/transcript.md#L493). Investigation: [L495](evidence/transcript.md#L495). Edit: [L498](evidence/transcript.md#L498). Commit/test command: [L500](evidence/transcript.md#L500).

[Readable context](excerpts/R50_05d0971.md) · [Exact diff](diffs/R50_05d0971.diff) · [Before](versions/af3dcdd.py) · [After](versions/05d0971.py)

## R51 · 4897e46 · Skip blockers already displaced from the goal

**Sequence:** Seed 53 fails after another object has displaced a blocker → recheck relevance and skip blockers already clear of the destination. → **recorded test batches:** L518: 1/1, 11/11, 5/5; L523: 3/3, 3/3, 3/3, 3/3, 3/3

Prior feedback: [L511](evidence/transcript.md#L511). Investigation: [L513](evidence/transcript.md#L513). Edit: [L516](evidence/transcript.md#L516). Commit/test command: [L518](evidence/transcript.md#L518).

[Readable context](excerpts/R51_4897e46.md) · [Exact diff](diffs/R51_4897e46.diff) · [Before](versions/05d0971.py) · [After](versions/4897e46.py)

Interpretation limits: Post-edit context includes final validation and stopping. L528 attempts a confidence-marker commit but returns nothing to commit; it is not a saved new policy revision.
