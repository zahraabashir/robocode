"""Feedback controller for variable-count Obstruction2D."""
import math
import numpy as np


class GeneratedApproach:
    def __init__(self, action_space, observation_space, primitives):
        self.action_space = action_space
        self.types = {t.name: t for t in observation_space.types}

    def reset(self, state, info):
        rects = state.get_objects(self.types["rectangle"])
        target_name = state.get_objects(self.types["target_block"])[0].name
        target = state.get_object_from_name(target_name)
        surface = state.get_objects(self.types["target_surface"])[0]
        sx, sw = state.get(surface, "x"), state.get(surface, "width")
        tx, tw = state.get(target, "x"), state.get(target, "width")
        target_angle = state.get(target, "theta")
        target_hx = 0.5 * (abs(math.cos(target_angle)) * tw +
                           abs(math.sin(target_angle)) * state.get(target, "height"))
        all_obstacles = [o for o in rects
                         if o.type.name == "rectangle" and state.get(o, "static") < 0.5]
        def blocks_goal(o):
            angle = state.get(o, "theta")
            hx = 0.5 * (abs(math.cos(angle)) * state.get(o, "width") +
                        abs(math.sin(angle)) * state.get(o, "height"))
            # Include near-edge objects because the gripper/base sweep has a
            # wider collision envelope than the block footprint itself.
            return abs(state.get(o, "x") - sx) < target_hx + hx + 0.12
        obstacles = [o for o in all_obstacles if blocks_goal(o)]
        obstacles.sort(key=lambda o: -state.get(o, "height"))
        # Temporarily lift the target only when it crowds an obstacle's access.
        crowded = any(abs(tx - state.get(o, "x")) <
                      0.5 * (tw + state.get(o, "width")) + 0.14 for o in obstacles)
        def top_y(o):
            angle = state.get(o, "theta")
            vertical_half = 0.5 * (abs(math.sin(angle)) * state.get(o, "width") +
                                   abs(math.cos(angle)) * state.get(o, "height"))
            return state.get(o, "y") + vertical_half
        tasks = sorted(obstacles, key=top_y, reverse=True)
        if crowded:
            target_top = top_y(target)
            def must_precede_target(o):
                angle = state.get(o, "theta")
                hx = 0.5 * (abs(math.cos(angle)) * state.get(o, "width") +
                            abs(math.sin(angle)) * state.get(o, "height"))
                overlaps = abs(state.get(o, "x") - tx) < hx + target_hx + 0.005
                return top_y(o) > target_top + 0.035 or (overlaps and top_y(o) > target_top)
            # Clear meaningfully taller neighbors first, then move the target
            # before near-tied lower objects can obstruct its pickup corridor.
            insert_at = sum(must_precede_target(o) for o in tasks)
            tasks.insert(insert_at, target)
        self.todo = [o.name for o in tasks]
        self.todo.append(target_name)  # retrieve it last for the actual placement
        # Greedily reserve floor-clear parking columns, preferring positions far
        # from both the pickup and goal.  The grid is count-independent.
        # Keep parking poses one base radius away from both side walls.
        candidates = [0.12] + [0.20 + 0.05 * k for k in range(23)] + [1.38, 1.46]
        # Allocate outermost slots first so a later blocker never has to pass
        # through an earlier parked one on the way out of the goal region.
        candidates.sort(key=lambda x: (abs(x - sx), abs(x - tx)), reverse=True)
        self.parking = {}
        self.parking_y = {}
        used = []
        first_rank = {}
        for rank, name in enumerate(self.todo):
            if name not in first_rank:
                first_rank[name] = rank
        self.target_park = tx
        if crowded:
            self.target_park = candidates[0]
            used.append((self.target_park, tw, target_name))
        for o in obstacles:
            ow = state.get(o, "width")
            goal_clearance = sw / 2 + tw / 2 + ow / 2 + 0.10
            future = [q for q in obstacles + [target]
                      if q.name != o.name and first_rank.get(q.name, 10**9) > first_rank[o.name]]
            valid = [x for x in candidates
                     if abs(x - sx) > goal_clearance
                     and all(abs(x - state.get(q, "x")) >
                             (ow + state.get(q, "width")) / 2 + 0.14 for q in future)
                     and all(abs(x - px) > (ow + pw) / 2 + 0.12
                             for px, pw, _ in used)]
            park_y = 0.30
            if valid:
                px = valid[0]
            else:
                # If strict margins cannot all fit, choose the least-violating
                # slot instead of blindly reusing an occupied column.
                def slot_slack(x):
                    margins = [abs(x - sx) - goal_clearance]
                    margins += [abs(x - state.get(q, "x")) -
                                ((ow + state.get(q, "width")) / 2 + 0.14)
                                for q in future]
                    margins += [abs(x - qx) - ((ow + qw) / 2 + 0.12)
                                for qx, qw, _ in used]
                    return min(margins)
                blocker_slots = [(qx, name) for qx, _, name in used if name != target_name]
                stack_slots = [item for item in blocker_slots
                               if not min(tx, sx) - 0.10 < item[0] < max(tx, sx) + 0.10]
                if len(obstacles) <= 2 and stack_slots:
                    px, _ = max(stack_slots, key=lambda item: abs(item[0] - sx))
                    level = sum(abs(qx - px) < 0.01 for qx, _, name in used
                                if name != target_name)
                    park_y = 0.30 + 0.20 * level
                else:
                    px = max(candidates, key=slot_slack)
            self.parking[o.name] = px
            self.parking_y[o.name] = park_y
            used.append((px, ow, o.name))
        self.final_index = len(self.todo) - 1
        xs = [state.get(state.get_object_from_name(n), "x") for n in state.get_object_names()]
        self.initial_x = {n: state.get(state.get_object_from_name(n), "x")
                          for n in state.get_object_names()}
        self.park_base = max(xs) + 0.45
        robot = state.get_objects(self.types["crv_robot"])[0]
        self.safe_y = state.get(robot, "y")
        self.index, self.phase, self.retry = 0, "orient", 0
        self.stalled, self.last_robot_y = 0, None
        self.last_robot_x = None
        self.pick_y, self.attached, self.release_wait = 0.0, False, 0
        self.grasp_dx = 0.0

    @staticmethod
    def _clip(v, limit):
        return max(-limit, min(limit, v))

    def _action(self, dx=0.0, dy=0.0, dtheta=0.0, darm=0.0, vac=0.0):
        a = np.array([dx, dy, dtheta, darm, vac], dtype=np.float32)
        return np.clip(a, self.action_space.low, self.action_space.high).astype(np.float32)

    def get_action(self, state):
        robot = state.get_objects(self.types["crv_robot"])[0]
        surface = state.get_objects(self.types["target_surface"])[0]
        rx, ry = state.get(robot, "x"), state.get(robot, "y")
        theta = state.get(robot, "theta")
        if self.index >= len(self.todo):
            return self._action()
        obj = state.get_object_from_name(self.todo[self.index])
        is_target = self.index == self.final_index
        ox, oy = state.get(obj, "x"), state.get(obj, "y")
        width = state.get(obj, "width")

        if not is_target and obj.type.name == "rectangle" and self.phase in ("rise", "align"):
            angle = state.get(obj, "theta")
            obstacle_hx = 0.5 * (abs(math.cos(angle)) * width +
                                 abs(math.sin(angle)) * state.get(obj, "height"))
            target = state.get_objects(self.types["target_block"])[0]
            target_angle = state.get(target, "theta")
            target_hx = 0.5 * (abs(math.cos(target_angle)) * state.get(target, "width") +
                               abs(math.sin(target_angle)) * state.get(target, "height"))
            if abs(ox - state.get(surface, "x")) >= obstacle_hx + target_hx + 0.12:
                self.index += 1
                self.retry, self.attached = 0, False
                self.phase = "rise"
                self.last_robot_x = None
                return self._action()

        if self.phase == "orient":
            err = (-math.pi / 2 - theta + math.pi) % (2 * math.pi) - math.pi
            if abs(err) < 0.025:
                self.phase = "rise"
            else:
                return self._action(dtheta=self._clip(err, 0.196))
        if self.phase == "rise":
            if ry >= self.safe_y - 0.004:
                self.phase = "align"
            else:
                return self._action(dy=min(0.05, self.safe_y - ry))
        if self.phase == "align":
            offsets = (0.0, -0.22, 0.22, -0.45, 0.45, -0.70, 0.70, -0.90, 0.90)
            tx = ox + offsets[min(self.retry, len(offsets) - 1)] * width
            if abs(tx - rx) < 0.004:
                self.phase, self.stalled = "descend", 0
                self.last_robot_y, self.pick_y = ry, oy
            else:
                if self.last_robot_x is not None and abs(rx - self.last_robot_x) < 0.001:
                    self.stalled += 1
                else:
                    self.stalled = 0
                self.last_robot_x = rx
                if self.stalled >= 3:
                    self.retry = min(len(offsets) - 1, self.retry + 1)
                    self.stalled = 0
                # Keep suction off in transit: a previously parked object may
                # touch the gripper as it passes underneath.
                return self._action(dx=self._clip(tx - rx, 0.05), vac=0.0)
        if self.phase == "descend":
            # A neighboring floating object can be pushed downward before the
            # vacuum acquires it.  Verify lift relative to the lowest observed
            # height, not merely its height at the start of the approach.
            self.pick_y = min(self.pick_y, oy)
            if self.last_robot_y is not None and abs(ry - self.last_robot_y) < 0.001:
                self.stalled += 1
            else:
                self.stalled = 0
            self.last_robot_y = ry
            if self.stalled >= 2 or ry < 0.18:
                self.phase = "lift"
                self.contact_robot_y = ry
                self.stalled = 0
                self.last_robot_y = ry
            else:
                # Fine approach is essential: collision resolution rejects an
                # overshooting move wholesale, leaving the vacuum just off-contact.
                return self._action(dy=-0.01, vac=1.0)
        if self.phase == "lift":
            if abs(ry - self.last_robot_y) < 0.001:
                self.stalled += 1
            else:
                self.stalled = 0
            self.last_robot_y = ry
            if oy > self.pick_y + 0.015:
                if not self.attached:
                    self.grasp_dx = ox - rx
                self.attached = True
            # A modest vertical park is enough to clear the ground while still
            # leaving room above it for a later verified re-grasp.
            park_y = (0.45 if obj.type.name == "target_block"
                      else self.parking_y.get(obj.name, 0.30))
            parked_high_enough = (not is_target and self.attached and oy >= park_y)
            if not self.attached:
                lift_limit = min(0.74, self.contact_robot_y + 0.15)
            else:
                lift_limit = self.safe_y if is_target else 0.74
            if ry < lift_limit - 0.004 and not parked_high_enough and self.stalled < 2:
                return self._action(dy=min(0.05, self.safe_y - ry), vac=1.0)
            if not self.attached:
                self.retry += 1
                if self.retry < 9:
                    self.phase = "align"
                    return self._action()
                if not is_target:
                    self.index += 1
                    self.retry = 0
                    self.phase = "rise"
                    return self._action()
                self.retry, self.phase = 0, "align"
                return self._action()
            self.phase = "carry"
            self.stalled, self.last_robot_x = 0, rx
        if self.phase == "carry":
            if is_target:
                desired_obj_x = state.get(surface, "x") + 0.008
            elif obj.type.name == "target_block":
                desired_obj_x = self.target_park
            else:
                desired_obj_x = self.parking[obj.name]
            tx = desired_obj_x - self.grasp_dx
            if abs(tx - rx) > 0.004:
                if self.last_robot_x is not None and abs(rx - self.last_robot_x) < 0.001:
                    self.stalled += 1
                else:
                    self.stalled = 0
                self.last_robot_x = rx
                if self.stalled >= 3 and not is_target:
                    self.phase = "release"
                else:
                    return self._action(dx=self._clip(tx - rx, 0.05), vac=1.0)
            else:
                self.phase = "lower" if is_target else "release"
            self.stalled, self.last_robot_y = 0, ry
        if self.phase == "lower":
            if abs(ry - self.last_robot_y) < 0.001:
                self.stalled += 1
            else:
                self.stalled = 0
            self.last_robot_y = ry
            if self.stalled >= 3:
                self.phase = "release"
            else:
                return self._action(dy=-0.01, vac=1.0)
        if self.phase == "release":
            self.release_wait += 1
            if self.release_wait < 2:
                return self._action()
            self.phase = "retreat"
        if self.phase == "retreat":
            if ry < self.safe_y - 0.004:
                return self._action(dy=min(0.05, self.safe_y - ry))
            self.index += 1
            self.retry, self.attached, self.release_wait = 0, False, 0
            self.last_robot_x = None
            self.phase = "align" if self.index < len(self.todo) else "done"
            return self._action()
        return self._action()
