# Sequences beyond a single repair

These are examples grounded in this run, not an exhaustive taxonomy. The arrows denote visible chronological relationships; they do not establish hidden causal reasoning. They can overlap with a code-repair sequence because they address a different question about the agent's activity.

## P1. Ask a question about the environment → vary an action → inspect what changes

At [L12](evidence/transcript.md#L12), the agent announces kinematics and collision probes. [L24](evidence/transcript.md#L24) and [L26](evidence/transcript.md#L26) exercise approach, descent and lifting. [L47](evidence/transcript.md#L47) compares arm extensions; [L83](evidence/transcript.md#L83) and [L86](evidence/transcript.md#L86) vary grasp angles/offsets. These are experiments performed outside the saved controller.

Plain sequence: **uncertain how grasping works → try controlled movements → inspect object displacement**.

Research question: Is a probe designed to distinguish alternative explanations, or does it simply search many settings? Both can occur. Read what varies and what stays fixed; do not infer the answer from the word “probe.” A parameter sweep is not automatically a world model or model-based planning.

## P2. State an explanation → encounter contrary evidence → develop a different implementation

At [L35](evidence/transcript.md#L35), the agent states that vacuum lifting works on the purple target but not the red obstructions and proposes pushing obstructions. Yet [L55](evidence/transcript.md#L55) records positive vertical displacement for rectangles in seeds 1 and 9, and [L71](evidence/transcript.md#L71) explicitly lifts `obstruction0` and checks its height after vacuum release. The saved controller at [R01](excerpts/R01_670d6a3.md) contains grasp/lift/park phases.

Plain sequence: **“obstructions cannot be lifted” → a later probe lifts one → saved policy includes lifting obstructions**.

Supported: the stated broad explanation is contradicted by subsequent recorded observations, and the eventual implementation differs from the proposed push-only direction. Not established: an explicit verbal acknowledgment of that contradiction, or the internal process by which the agent revised its belief.

Research question: How often do stated explanations persist, narrow, or disappear when new evidence conflicts with them? This is directly relevant to your interest in models of the world, while respecting the incomplete reasoning record.

## P3. A complex failure → choose a simpler case → isolate a component

Following unsuccessful placements, [L161](evidence/transcript.md#L161) explicitly searches for seeds with zero obstructions. [L163](evidence/transcript.md#L163) tests three of them; all fail. [L165–169](excerpts/R10_735b56a.md) inspect grasps and robot geometry. Later, [L189](evidence/transcript.md#L189) uses fine downward movements and records successful lifts across six selected cases, followed by the fine-step code change in [R12](diffs/R12_af4477f.diff).

Plain sequence: **failure with obstacles → test without obstacles → failure still exists → investigate grasping itself**.

Research question: Does the agent simplify a problem to separate competing causes? These naturally sampled zero-obstruction scenes also differ in other properties, so they are not a controlled obstacle-removal intervention.

## P4. A targeted success → check other cases → find a regression → refine again

[L348](evidence/transcript.md#L348) solves seed 18. The next targeted checks at [L351](evidence/transcript.md#L351) fail on seeds 39 and 45. After a parking edit, [L358](evidence/transcript.md#L358) solves those two but fails on previously passing seed 3. The next edit and [L366](evidence/transcript.md#L366) restore seed 3.

Plain sequence: **fix A → discover B still fails → fix B → A or another earlier case breaks → refine again**.

Research question: How does the agent respond to tradeoffs between cases? Inspect whether it adds a condition, adjusts a threshold, changes another component, or restores earlier code. Avoid summarizing this as steady improvement.

## P5. Try a new rule → performance worsens → return to earlier code

[R26](excerpts/R26_f064af0.md) introduces high blocker carries and a lowering phase. [L289](evidence/transcript.md#L289) reports only 5/11 baseline successes. Another adjustment at [L293](evidence/transcript.md#L293) remains at 5/11. [R28](diffs/R28_13fcd58.diff) removes those changes; [L297](evidence/transcript.md#L297) reaches 8/11. Further reversals follow in R29 and R30.

Plain sequence: **new mechanism → regression persists → restore earlier behavior → retest**.

The source hashes show three exact revisits to earlier complete `approach.py` contents in this run (listed in the manifest). This supplies stronger evidence of returning to an earlier program than a commit title alone.

Research question: How much negative feedback does the agent accumulate before abandoning a change? Do not count repeated tests as independent agents or infer resource rationality from a single reversal.

## P6. Discover an evaluation capability → broaden test coverage → expose a new problem class

[L404](evidence/transcript.md#L404) and [L406](evidence/transcript.md#L406) inspect the public client's reset options. [L407](evidence/transcript.md#L407) connects pinned object counts with the task requirement; [L409](evidence/transcript.md#L409) changes the test harness, and [L411](evidence/transcript.md#L411) tests three obstructions. Later [L426](evidence/transcript.md#L426) tests four and attempts five.

Plain sequence: **notice an untested requirement/capability → extend the tester → test harder conditions → discover new failures**.

An informative complication: [L401](evidence/transcript.md#L401) already reports seed 85 failing in the ordinary sweep. The visible subsequent sequence expands counts without first showing a targeted seed-85 repair. Thus coverage expansion does not require every observed failure to have been resolved.

Research question: How does the agent choose between repairing a known failure and checking a different requirement? The record supports studying that choice; it does not show that either choice was optimal.

## P7. Attempt a test → environment cannot initialize → report a coverage limit

Count-5 attempts at [L426](evidence/transcript.md#L426), [L449](evidence/transcript.md#L449), and [L504](evidence/transcript.md#L504) fail during environment reset because sampling exhausts 10,000 attempts. The agent reports this limitation at [L507](evidence/transcript.md#L507) and in its final message.

Plain sequence: **try a test → cannot create the scene → acknowledge missing coverage**.

Research question: Can the agent distinguish “my policy failed” from “the requested test could not run”? Do not score these as failed robot episodes; they are reset failures.

## P8. Finish and report uncertainty → resume development; later gather evidence → report confidence

At [L324](evidence/transcript.md#L324) and [L327](evidence/transcript.md#L327), the agent hands off with residual failures and no confidence marker. A turn ends at L328; another starts at L330, with the continuation message at [L331](evidence/transcript.md#L331). This is the same recorded thread/run, not an independent replicate. The trigger for continuation is not established by the stream alone.

Later, [L521](evidence/transcript.md#L521) states a proposed final validation condition; [L523](evidence/transcript.md#L523) returns 15/15 across counts 0–4; [L524](evidence/transcript.md#L524) announces confidence. L526 creates the marker and [L531](evidence/transcript.md#L531) checks its presence. L528's attempted commit fails with “nothing to commit”; it is not a new policy revision.

Plain sequences: **residual uncertainty → handoff → resumed work**; **stated stopping condition → final tests → confidence declaration**.

Research question: What evidence does the agent cite when deciding to stop? Budget checks and stopping messages are visible, but proving resource-rational stopping requires comparing choices under different costs/budgets and expected benefits. This run alone does not establish that.

## P9. An action has a useful side effect → planned work becomes unnecessary → skip it

[L511](evidence/transcript.md#L511) finds seed 53 failing. [L513](evidence/transcript.md#L513) prints the stuck controller and object positions. At [L514](evidence/transcript.md#L514), the agent explains that moving one object has already displaced another. [R51](diffs/R51_4897e46.diff) adds a live relevance check, and [L518](evidence/transcript.md#L518) reports success.

Plain sequence: **earlier movement clears another blocker → old task list still tries to grasp it → add a check to skip unnecessary work**.

Research question: When does the agent replace a fixed task list with decisions based on the current state? This is evidence about the generated controller's mechanism. It does not, by itself, classify the coding agent as model-based.

## How to use these examples

Pick one question, inspect two supporting examples, and deliberately look for a counterexample. Keep the remaining patterns as future ideas. Their existence is a reason to broaden the initial map, not a requirement to deeply annotate everything at once.
