# Practice forming one hypothesis from this run

Start with **“How does the agent choose what to test next?”** This concerns the coding agent's decision-making and can be investigated using visible actions without access to internal reasoning.

## 1. Notice a possible pattern

You can observe **a failing test → a focused diagnostic probe**, for example L358 → L360, and **successful local checks → a broader sweep**, for example L366 → L370. Read the [full event index](event_index.md) to see other transitions as well.

These examples suggest a pattern. They do not yet establish how frequent it is, why it occurs, or whether it is rational.

## 2. Write a strong version that could be wrong

> H0: The agent resolves every observed failure before broadening test coverage.

This is precise enough to check. In the visible record it fails: [L401](evidence/transcript.md#L401) reports ordinary seed 85 failing; [L404–411](excerpts/R40_0e14ec7.md) then discover pinned-count testing, extend the harness and test count 3, without an intervening visible targeted seed-85 repair. We cannot conclude that the agent ignored the failure internally; the narrower observation is that the next visible test expansion did not wait for a recorded repair of it.

Rejecting a first hypothesis is progress. You have learned that a simple “close every failure before exploring” description is inadequate.

## 3. Develop a more useful question

> Under what circumstances does this agent prioritize a known failure, and when does it prioritize testing a different task requirement?

A provisional hypothesis is that **recent outcomes and perceived gaps in test coverage jointly influence the next experiment**. The pinned-count message explicitly mentions the variable-count requirement. This remains an exploratory interpretation, not an established causal model.

For a small manual exercise, inspect ten transitions spread across the run, including successes, failures, mixed outcomes and the coverage-expansion counterexample. Do not select only episodes fitting the hypothesis. A possible evenly spread starting list of feedback events is L94, L144, L193, L242, L293, L348, L378, L401, L458 and L518; record what follows rather than taking the listed outcomes as labels.

## 4. Fill in a small table

| Feedback event | What was observed? | What did the agent do next? | What information did the next experiment seek? | Evidence for its stated reason | Alternative explanation |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

Use these plain categories for the next substantive action: **diagnostic probe**, **policy edit**, **test known difficult cases**, **broaden seeds**, **broaden object counts**, **stop**, or **unclear/mixed**. These are working analysis categories, not ACT*ONOMY subactions.

Ignore administrative commands such as `git status` when finding the next substantive action, but preserve them in the source. Do not skip a policy edit merely to reach the next test: an immediate edit is itself informative. If one command runs both targeted and broad tests, label the combination rather than forcing a single category.

Identify a test by seed, object-count setting, policy version and harness version. Mark whether a failure was just observed or only known from an older policy. Group related repeated tests; use source line numbers to avoid counting overlapping excerpts twice. Tool completion order and asynchronous activity should be checked before assuming a strict observation-to-choice relationship.

## 5. Know what the exercise can establish

It can establish which transitions are visible in this run, where its stated explanations align with its actions, and which proposed descriptions fail. It cannot establish population frequencies, internal cognitive mechanisms, or causal effects of feedback from ten selected transitions.

If the categories become clear and useful, apply the same rule to every eligible transition in this run and report counts with the appropriate denominator. Preserve negative and ambiguous cases. Only then decide whether to validate the categories on another run or conduct a controlled experiment.

A later causal experiment could present fresh agent continuations with the same failed program and visible context but different diagnostic feedback, holding the budget and task constant. Replaying two robot programs instead tests the effect of their code differences; it does not test how the coding agent chooses its next investigation.

## Relation to your model-based/model-free interest

Probes can gather information needed for a world model, but probing alone does not prove model-based planning. Keep a separate evidence column for an explicit prediction, a comparison of action consequences, or an executed simulator/model. “Not visible” is a valid result. A geometry rule, a textual explanation, and a predictive simulator should not receive the same label automatically.

Your immediate deliverable is one short paragraph: **pattern noticed → proposed hypothesis → counterexample → revised question → next evidence needed**. You do not need to automate all labels or explain all 51 revisions to complete this exercise.
