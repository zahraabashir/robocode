"""Read archived session metadata and selected public messages; never execute them."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
ARCHIVE = Path(json.loads((ROOT / 'manifest.json').read_text())['archive_run'])
session_audit = []
selected_messages = []
selected = {
    'rollout-2026-09-08T22-08-33-01a082a2-f8b8-7c61-a29b-46574d0345ee.jsonl': [40],
    'rollout-2026-09-08T23-02-20-01a082d4-33c4-7a02-8922-e54dc085f63f.jsonl': [79],
    'rollout-2026-09-08T23-02-29-01a082d4-56bf-7120-9d77-c12d3440135f.jsonl': [74],
}
for path in sorted((ARCHIVE / 'sandbox/.agent_sessions').rglob('rollout*.jsonl')):
    content = path.read_bytes()
    counts = dict(reasoning_records=0, encrypted_nonempty=0,
                  summary_nonempty=0, content_nonempty=0)
    for line, text in enumerate(content.decode().splitlines(), 1):
        event = json.loads(text)
        payload = event.get('payload', {})
        if payload.get('type') == 'reasoning':
            counts['reasoning_records'] += 1
            for key, field in [('encrypted_nonempty', 'encrypted_content'),
                               ('summary_nonempty', 'summary'), ('content_nonempty', 'content')]:
                counts[key] += bool(payload.get(field))
        if line in selected.get(path.name, []):
            assert payload.get('type') == 'message' and payload.get('role') == 'assistant'
            message = '\n'.join(c.get('text', '') for c in payload.get('content', []))
            selected_messages.append(dict(source=str(path), line=line,
                timestamp=event.get('timestamp'), actor='archived helper agent', text=message))
    session_audit.append(dict(source=str(path), sha256=hashlib.sha256(content).hexdigest(), **counts))

stream = ROOT / 'evidence/stream.jsonl'
for line, text in enumerate(stream.read_text().splitlines(), 1):
    if line in [155,338,374,383,392,454,514]:
        event = json.loads(text)
        assert event['type'] == 'item.completed' and event['item']['type'] == 'agent_message'
        selected_messages.append(dict(source=str(stream), line=line,
            actor='main coding agent', text=event['item']['text']))

output = dict(scope='Eight preserved rollout files; counts are records, not unique thoughts. '
                   'Forked sessions can repeat inherited history. Encrypted payloads omitted. '
                   'Selected helper messages are proposals, not proof of execution or main-agent adoption.',
              session_audit=session_audit, selected_messages=selected_messages)
(ROOT / 'model_evidence.json').write_text(json.dumps(output, indent=2) + '\n')
lines = ['# Selected readable evidence about prediction and planning', '', output['scope'], '']
for i, message in enumerate(selected_messages, 1):
    lines += [f'## E{i}: {message["actor"]}', '',
              f'Source: `{message["source"]}`; original line {message["line"]}.', '',
              message['text'], '']
(ROOT / 'model_evidence_excerpts.md').write_text('\n'.join(lines))
print(json.dumps(dict(files=len(session_audit),
                     reasoning_records=sum(s['reasoning_records'] for s in session_audit),
                     readable_reasoning_records=sum(s['summary_nonempty'] or s['content_nonempty'] for s in session_audit),
                     selected_messages=len(selected_messages)), indent=2))
