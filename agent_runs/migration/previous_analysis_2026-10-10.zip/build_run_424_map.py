"""Read-only reconstruction of the main stream and saved policy revisions in run 424.

No archived commands, prompts, or programs are executed. Interpretive descriptions
below are analyst notes, not ACT*ONOMY labels or recovered internal reasoning.
"""
import ast
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
SOURCE = Path(json.loads((HERE / 'obstruction2d_seed18/provenance.json').read_text())['archive_run'])
OUT = HERE / 'run_424_sequence_map'

# Commit, prior problem evidence, diagnostic events, plain description of actual edit.
# A chronological connection is an observation, not proof of the agent's motivation.
REVISIONS = [
 ('670d6a3', [20,22], [24,26,34,55,66,71,73], 'Baseline stalls; explore manipulation → replace it with a controller that tracks movement phases and retries.'),
 ('55d3dab', [79,88], [90], 'Robot stays in the rise phase → use its initial height as the reachable travel height.'),
 ('98c6f07', [94,99], [102], 'Multi-object cases still fail → reorder rectangles tallest first and include an initial target-clearing pass.'),
 ('6d93a7d', [106], [108], 'Printed task list includes the static surface and motion stalls → filter static objects and park vertically in place.'),
 ('e727013', [112], [114], 'Target moves while the robot travels toward another object → turn vacuum off during horizontal alignment.'),
 ('5a9cda5', [118], [120], 'Objects remain high and the target cannot be regrasped → stop preliminary lifts at a lower parking height.'),
 ('f214f7d', [124], [126], 'Controller finishes but placement fails → move obstructions laterally away from the surface.'),
 ('dd0457e', [132], [136,138,140], 'Broader tests mostly fail → temporarily move the target only when the geometry is crowded.'),
 ('3f73fd4', [144], [146], 'Failure persists with a moving obstruction destination → calculate that destination from the initial object position.'),
 ('735b56a', [150,163], [152,154,157,165,167,169,171,173], 'Program placement fails despite a successful hand-scripted placement probe → lower the carry-height threshold.'),
 ('b15ba76', [177], [], 'Lower carry height does not solve seed 1 → add a small horizontal offset to final placement.'),
 ('af4477f', [183], [185,187,189], 'Several grasp cases fail; a fine-step probe lifts them → reduce downward steps from 0.05 to 0.01.'),
 ('9c6bdf4', [193], [195,197], 'Robot stalls in retreat below its requested height → cap the upward step at the remaining height.'),
 ('4f80855', [201], [203], 'Target access and boundary cases remain → change parking direction and detect stalled horizontal carrying.'),
 ('2d184c4', [207], [209], 'Failures remain after new parking rule → vary parking heights and add stalled-alignment recovery.'),
 ('0c006f7', [213], [215,217], 'Objects still obstruct target movement → return to lower parking and move blockers farther away from the surface.'),
 ('adf84ae', [221,223], [225], 'Several target pickups remain blocked → expand grasp offsets and compensate for the object-to-gripper offset.'),
 ('b7ccec6', [229], [231], 'Multi-obstacle parking failures persist → rank candidate parking positions by geometric clearance.'),
 ('0f0c2ee', [236], [238], 'Three regression cases still fail → reserve a remote parking position for the temporarily moved target.'),
 ('71c469c', [242], [244], 'Seed 3 stalls while carrying the final target → increase final target carry height.'),
 ('2185ba3', [248], [250], 'Seed 5 fails after earlier fixes → move candidate parking positions away from side walls.'),
 ('8e66f4e', [254], [256], 'Seed 5 still stalls in lift → cap upward movement at the reachable ceiling.'),
 ('3098aab', [263], [265,267], 'A broader sweep finds seeds 18 and 22 failing → raise temporary target parking and final carry height.'),
 ('5075837', [271], [273], 'Both targeted cases still fail → choose an outward target slot and lower blocker parking.'),
 ('0605fd3', [277], [279], 'Seed 18 remains unresolved → restrict blocker parking to the same side of the surface.'),
 ('f064af0', [283], [285], 'Seed 18 remains unresolved → carry blockers higher and add a separate lowering phase.'),
 ('a4cb1db', [289], [], 'Seed 18 and six baseline cases fail → allow a blocker lift to finish at the reachable ceiling.'),
 ('13fcd58', [293], [], 'The broad failures persist → undo the high-carry/lowering changes and restore low parking.'),
 ('04141a4', [297], [], 'Three baseline failures remain → remove the same-side parking restriction.'),
 ('3f93ca0', [301], [303], 'Seed 10 remains unresolved → remove the outward-only target parking rule.'),
 ('990576d', [307,311], [313], 'Several clustered cases fail → reduce the spacing margin between parked objects.'),
 ('a11bd5f', [317], [], 'Smaller spacing leaves all four targeted cases failing → restore the earlier spacing margin → compile and hand off without a fresh rollout report in that turn.'),
 ('c1c4586', [317,327], [335], 'Resume work on seed 18; inspect pickup heights → verify a lift against the lowest observed object height.'),
 ('e97a537', [342], [344], 'Seed 18 still fails and the controller reaches done → sort the initial task list by computed top height.'),
 ('c9b3655', [351], [353], 'Seeds 39 and 45 fail → add destination clearance and enlarge separation between parked objects.'),
 ('4d36a38', [358], [360,362], 'Seed 3 becomes a regression → insert the target earlier when blocker heights are close.'),
 ('be6feb6', [370], [373], 'Seeds 15 and 26 fail → widen the height tolerance AND reject parking slots near future pickups.'),
 ('616a82f', [380], [382], 'Seed 18 breaks again → include geometric overlap in the target-ordering criterion.'),
 ('dafcc2f', [389], [391], 'Seed 59 fails → allocate farther-from-surface parking positions before inner positions.'),
 ('0e14ec7', [411], [413], 'Pinned count-3 tests fail on seeds 1 and 3 → densify the parking grid and score fallback constraint violations.'),
 ('f87f63f', [417], [419], 'Count-3 seed 4 now fails → increase clearance around future pickup locations.'),
 ('6fc104f', [426], [428,430,432], 'Count-4 testing fails on four of five seeds → only relocate objects near the final placement footprint.'),
 ('c91cb8e', [437], [], 'Filtering leaves baseline seed 6 and count-4 cases failing → widen the footprint used to select blockers.'),
 ('bb1c5eb', [441], [443], 'Count-4 seed 1 still fails → enlarge the clearance around the final lowering location.'),
 ('20d09c8', [451], [453], 'Seed 93 fails with crowded horizontal parking → add a vertical stacking fallback.'),
 ('5210b1a', [458], [460], 'Stacking fixes seed 93 but breaks count-4 cases → restrict stacking to outer columns and small blocker sets.'),
 ('4868fc2', [469], [471], 'New count-4 failures appear → shorten the verification/recovery lift when no attachment is detected.'),
 ('7cfa55b', [475], [477], 'Count-4 seed 5 still fails → add a tolerance to the lift-height stopping condition.'),
 ('af3dcdd', [481], [483,485], 'Seed 5 remains stuck in lift → detect vertical stalls and enter recovery.'),
 ('05d0971', [493], [495], 'Count-4 seed 7 remains unresolved → add parking candidates near both boundaries.'),
 ('4897e46', [511], [513], 'Seed 53 fails after another object has displaced a blocker → recheck relevance and skip blockers already clear of the destination.'),
]


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(SOURCE / 'sandbox'), *args])


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, data):
    if isinstance(data, str):
        data = data.encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() != data:
        raise RuntimeError(f'Refusing to overwrite modified output: {path}')
    path.write_bytes(data)


raw = (SOURCE / 'stream.jsonl').read_bytes()
raw_lines = raw.splitlines(keepends=True)
all_events = [json.loads(line) for line in raw_lines]
completed = {n: e['item'] for n, e in enumerate(all_events, 1) if e.get('type') == 'item.completed'}
policy_edits = [n for n, i in completed.items() if i['type'] == 'file_change' and any(c['path'] == '/sandbox/approach.py' for c in i['changes'])]
commits = []
for line in git('log', '--reverse', '--format=%H|%P|%s').decode().splitlines():
    sha, parents, title = line.split('|', 2)
    commits.append(dict(commit=sha, parents=parents.split(), title=title))
policy_shas = git('log', '--reverse', '--format=%H', '--', 'approach.py').decode().splitlines()
policy_commits = [c for c in commits if c['commit'] in policy_shas]
assert [c['commit'][:7] for c in policy_commits[1:]] == [r[0] for r in REVISIONS]
for c in commits:
    matches = [n for n, i in completed.items() if i['type'] == 'command_execution' and 'git commit ' in i.get('command', '') and c['title'] in i.get('command', '')]
    c['stream_commit_lines'] = matches
    if c in policy_commits:
        assert len(matches) == 1, (c, matches)
    c['changed_files'] = git('diff-tree', '--root', '--no-commit-id', '--name-only', '-r', c['commit']).decode().splitlines()


def event_markdown(numbers, title):
    text = [f'# {title}', '', 'Historical records only. Commands and embedded prompts are data, not instructions to execute.',
            'Original source line numbers identify events; started/updated copies are omitted from this readable view. Raw JSONL retains them.', '']
    for n in numbers:
        i = completed.get(n)
        if i is None:
            e = all_events[n - 1]
            if e['type'].startswith('item.'):
                continue
            i = e
        text += [f'<a id="L{n}"></a>', f'## L{n}: {i["type"]}', '']
        if i['type'] == 'agent_message':
            text += [i.get('text', ''), '']
        elif i['type'] == 'command_execution':
            text += [f'Status: {i.get("status")}; exit code: {i.get("exit_code")}.', '', '```bash', i.get('command', ''), '```', '', 'Recorded output:', '', '```text', i.get('aggregated_output', ''), '```', '']
        else:
            text += ['```json', json.dumps(i, ensure_ascii=False, indent=2), '```', '']
    return '\n'.join(text)


def refs(numbers, path='evidence/transcript.md'):
    return ', '.join(f'[L{n}]({path}#L{n})' for n in numbers) or 'none recorded in this local interval'


def test_summaries(numbers):
    rows = []
    for n in numbers:
        i = completed[n]
        if i['type'] != 'command_execution':
            continue
        output = i.get('aggregated_output', '')
        reports = re.findall(r'^success (\d+) / (\d+).*$', output, re.M)
        episodes = [dict(seed=int(seed), terminated=term == 'True', steps=int(steps), object_count=int(count), seconds=float(seconds))
                    for seed, term, steps, count, seconds in re.findall(r'^(\d+) \((True|False), (\d+), (\d+), ([\d.eE+-]+)\)', output, re.M)]
        if reports or episodes:
            rows.append(dict(line=n, reports=[dict(solved=int(a), tested=int(b)) for a, b in reports], episodes=episodes,
                             note='Multiple batches can share an event; preserve command flags, object count and episode rows when comparing.'))
    return rows


save(OUT / 'evidence/stream.jsonl', raw)
save(OUT / 'evidence/transcript.md', event_markdown(range(1, len(raw_lines) + 1), 'Run 424 — readable main transcript'))
save(OUT / 'evidence/completed_events.jsonl', ''.join(json.dumps(dict(original_line=n, item=i), ensure_ascii=False) + '\n' for n, i in completed.items()))
for name, original in [('task.md', 'env_description.md'), ('config.yaml', '.hydra/config.yaml')]:
    save(OUT / 'evidence' / name, (SOURCE / original).read_bytes())

snapshot_hashes = {}
for c in policy_commits:
    data = git('show', c['commit'] + ':approach.py')
    ast.parse(data)
    save(OUT / 'versions' / (c['commit'][:7] + '.py'), data)
    snapshot_hashes[c['commit']] = digest(data)

inventory = []
overview = ['# All 51 subsequent policy revisions', '',
    'This is an exhaustive inventory of saved policy changes after the initial baseline in this run, not a claim that all changes were successful or that every uncommitted intermediate program is recoverable.',
    'Each arrow means chronological progression. Descriptions are analyst summaries of observed actions and code, not recovered internal thoughts or formal ACT*ONOMY labels.',
    'Reported solve counts are separate historical test batches. Do not add them across versions or compare different seeds/count settings as if they were the same test.', '',
    'The previously studied five cases are R34–R38. Read one linked excerpt and diff to audit a sequence.', '']
covered_edits = [policy_edits[0]]
for idx, (short, feedback, probes, description) in enumerate(REVISIONS, 1):
    c = policy_commits[idx]
    prior = policy_commits[idx - 1]
    parent = c['parents'][0]
    commit_line = c['stream_commit_lines'][0]
    prior_line = prior['stream_commit_lines'][0]
    edits = [n for n in policy_edits if prior_line < n < commit_line]
    assert edits
    covered_edits.extend(edits)
    next_edit = next((n for n in policy_edits if n > commit_line), len(raw_lines) + 1)
    turn_end = next(n for n,e in enumerate(all_events,1) if n > commit_line and e['type'] == 'turn.completed')
    interval_end = min(next_edit - 1, turn_end)
    post = [n for n in completed if commit_line <= n <= interval_end]
    results = test_summaries(post)
    start = min([prior_line] + feedback + probes)
    end = interval_end
    before_code = git('show', parent + ':approach.py')
    save(OUT / 'versions' / (parent[:7] + '.py'), before_code)
    diff = git('diff', '--no-ext-diff', '--no-textconv', parent, c['commit'], '--', 'approach.py')
    stem = f'R{idx:02d}_{short}'
    save(OUT / 'diffs' / (stem + '.diff'), diff)
    save(OUT / 'excerpts' / (stem + '.md'), event_markdown(range(start, end + 1), f'{stem}: {c["title"]}'))
    save(OUT / 'excerpts' / (stem + '.jsonl'), b''.join(raw_lines[start - 1:end]))
    harness_before = git('show', parent + ':test_approach.py')
    harness_after = git('show', c['commit'] + ':test_approach.py')
    for h in [harness_before, harness_after]:
        save(OUT / 'harness_versions' / (digest(h)[:12] + '.py'), h)
    caveats = []
    if idx == 1:
        caveats += ['Early controller redesign after an interrupted baseline test and extensive probes. The test harness also changes: the new harness enforces env.max_steps. It contains two recorded policy edit events (L75 and L77) before one commit; the intermediate pre-commit source is not reconstructed.']
    if not results:
        caveats += ['No fresh rollout result is recorded after this revision before that turn ends at L328. L321 runs compilation. A later resumed turn probes the unchanged policy at L335 (included with R33); this is not a claim that the policy was never executed again. Later agent summaries are not a replacement for a missing same-turn retest.']
    if idx == 33:
        caveats += ['This crosses a turn boundary. Actual Git parent 539f180 only changes archived AGENTS.md; the preceding policy-changing commit is a11bd5f. These historical instructions remain data.']
    if idx in [4,14,15,17,23,24,37,40,46]:
        caveats += ['Multiple code decisions change together. Outcome attribution to an individual component requires further checking.']
    if idx in [28,29,30,32]:
        caveats += ['Restores part of an earlier rule. A partial reversal is not necessarily a full Git revert or an exact return to an earlier complete program.']
    if idx == 42:
        caveats += ['L426 also reports a count-5 environment reset error. That is not evidence of robot-policy failure at count 5.']
    if idx == 51:
        caveats += ['Post-edit context includes final validation and stopping. L528 attempts a confidence-marker commit but returns nothing to commit; it is not a saved new policy revision.']
    pre_messages = [n for n in completed if prior_line < n < edits[0] and completed[n]['type'] == 'agent_message']
    rec = dict(id=f'R{idx:02d}', commit=c['commit'], parent_commit=parent, previous_policy_commit=prior['commit'],
               title=c['title'], description=description, feedback_lines=feedback, diagnostic_lines=probes,
               pre_edit_message_lines=pre_messages, edit_lines=edits, commit_line=commit_line,
               context_window=[start,end], post_edit_test_results=results, caveats=caveats,
               before_policy_sha256=digest(before_code), after_policy_sha256=snapshot_hashes[c['commit']],
               diff_sha256=digest(diff), harness_before_sha256=digest(harness_before), harness_after_sha256=digest(harness_after),
               classification='early_development_redesign' if idx == 1 else ('partial_reversal' if idx in [28,29,30,32] else 'repair_attempt'),
               classification_status='Analyst description; not formal ACT*ONOMY annotation.')
    inventory.append(rec)
    results_text = '; '.join(f'L{r["line"]}: ' + ', '.join(f'{v["solved"]}/{v["tested"]}' for v in r['reports']) for r in results) or 'No policy retest in this interval; compilation only.'
    overview += [f'## R{idx:02d} · {short} · {c["title"]}', '',
                 f'**Sequence:** {description} → **recorded test batches:** {results_text}', '',
                 f'Prior feedback: {refs(feedback)}. Investigation: {refs(probes)}. Edit: {refs(edits)}. Commit/test command: {refs([commit_line])}.', '',
                 f'[Readable context](excerpts/{stem}.md) · [Exact diff](diffs/{stem}.diff) · [Before](versions/{parent[:7]}.py) · [After](versions/{short}.py)', '']
    if caveats:
        overview += ['Interpretation limits: ' + ' '.join(caveats), '']
assert sorted(covered_edits) == policy_edits
save(OUT / 'repair_sequences.md', '\n'.join(overview))
save(OUT / 'revision_inventory.json', json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
save(OUT / 'commit_inventory.json', json.dumps(commits, ensure_ascii=False, indent=2) + '\n')

# Compact chronological index of every completed main-stream event; neutral event types only.
event_rows = ['# All completed main-stream events', '', 'An index, not a taxonomy annotation. Original line numbers preserve order and distinguish repeated item IDs across turns.', '',
              '| Line | Recorded event type | Description |', '| --- | --- | --- |']
for n, i in completed.items():
    if i['type'] == 'agent_message':
        label = i.get('text', '').splitlines()[0]
    elif i['type'] == 'command_execution':
        command = i.get('command', '')
        label = command if 'git commit ' in command else command.splitlines()[0]
        reports = re.findall(r'^success (\d+) / (\d+)', i.get('aggregated_output', ''), re.M)
        label += ' [batches: ' + ', '.join(f'{a}/{b}' for a,b in reports) + ']' if reports else ''
    elif i['type'] == 'file_change':
        label = ', '.join(c['path'] for c in i['changes'])
    else:
        label = str(i.get('tool', ''))
    label = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', label)
    label = label.replace('|', '\\|').replace('\n', ' ')
    event_rows.append(f'| [L{n}](evidence/transcript.md#L{n}) | {i["type"]} | {label[:220]} |')
save(OUT / 'event_index.md', '\n'.join(event_rows) + '\n')

duplicates = defaultdict(list)
for sha, value in snapshot_hashes.items():
    duplicates[value].append(sha[:7])
manifest = dict(archive_run=str(SOURCE), extraction_scope='main stream.jsonl plus saved sandbox Git history; not an exhaustive search of backend sessions',
                source_stream_sha256=digest(raw), source_stream_lines=len(raw_lines), completed_events=len(completed),
                completed_event_types=dict(Counter(i['type'] for i in completed.values())), saved_git_commits=len(commits),
                policy_changing_commits=len(policy_commits), subsequent_policy_revisions=len(inventory),
                unique_committed_policy_contents=len(duplicates), repeated_policy_contents=[v for v in duplicates.values() if len(v)>1],
                policy_file_change_events=len(policy_edits), policy_file_change_events_covered=sorted(covered_edits),
                revisions_with_post_edit_test_results=sum(bool(r['post_edit_test_results']) for r in inventory),
                revisions_without_post_edit_test_results=[r['id'] for r in inventory if not r['post_edit_test_results']],
                actual_git_head=git('rev-parse','HEAD').decode().strip(),
                final_working_policy_matches_HEAD=(SOURCE/'sandbox/approach.py').read_bytes()==git('show','HEAD:approach.py'),
                thread_start_lines=[n for n,e in enumerate(all_events,1) if e['type']=='thread.started'],
                turn_complete_lines=[n for n,e in enumerate(all_events,1) if e['type']=='turn.completed'],
                note='No archived commands executed, no robot replays run, no archive modifications. Overlapping excerpts are context, not independent observations.')
save(OUT / 'manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: manifest[k] for k in ['policy_changing_commits','subsequent_policy_revisions','unique_committed_policy_contents','revisions_with_post_edit_test_results','revisions_without_post_edit_test_results','completed_events']}, indent=2))
print(f'Wrote {OUT}')
