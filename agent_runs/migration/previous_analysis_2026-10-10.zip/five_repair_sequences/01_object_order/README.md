# 1. Change the order of moving objects

Same Obstruction2D coding-agent run, development replicate 424. Episode seeds below are environment test instances, not separate coding-agent runs.

Before commit: `c1c4586e18d6eb769aa82ec18799d7a6a5bd5dab`. After commit: `e97a5378cb34a8df18769cdf4c4b15f5bf5e674d`.

Read [trace_excerpt.md](trace_excerpt.md) → [change.diff](change.diff) → [before.py](before.py) and [after.py](after.py) as needed. Fill in [notes.md](notes.md) yourself; it is deliberately unlabelled.

## Find the sequence

These are ORIGINAL stream.jsonl line numbers, also shown as headings in the readable excerpt:

- Failure feedback: 342.
- Diagnostic probes: 344.
- Agent explanation, assessment or plan messages: 349.
- Edit event: 346.
- Retests: 348.

Recorded outcome: Seed 18: failure at 1,000 steps → success at 436. Seeds 0–10 remain 11/11.

Inspection focus: Compare how self.todo is constructed. A detailed explanation of why this ordering was chosen is not visible in this window.

The outcome is historical evidence, not a new replay or a proven causal explanation. Shared endpoint tests appear in adjacent packets as context; do not count them twice. See [provenance.json](provenance.json) for source locations and hashes.
