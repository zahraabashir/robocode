# 5. Refine ordering after seed 18 breaks again

Same Obstruction2D coding-agent run, development replicate 424. Episode seeds below are environment test instances, not separate coding-agent runs.

Before commit: `be6feb60cb8cb0981cde9814194135d920128e75`. After commit: `616a82f41c95f8f631d9813da952c4d62c8e5a85`.

Read [trace_excerpt.md](trace_excerpt.md) → [change.diff](change.diff) → [before.py](before.py) and [after.py](after.py) as needed. Fill in [notes.md](notes.md) yourself; it is deliberately unlabelled.

## Find the sequence

These are ORIGINAL stream.jsonl line numbers, also shown as headings in the readable excerpt:

- Failure feedback: 380.
- Diagnostic probes: 382.
- Agent explanation, assessment or plan messages: 383.
- Edit event: 385.
- Retests: 387.

Recorded outcome: Seed 18: failure → success at 436 steps. Seed 15 and seeds 0–10 also pass.

Inspection focus: Inspect must_precede_target and how its result determines the target’s insertion index. Compare the agent’s explanation about overlapping taller blockers with the actual code.

The outcome is historical evidence, not a new replay or a proven causal explanation. Shared endpoint tests appear in adjacent packets as context; do not count them twice. See [provenance.json](provenance.json) for source locations and hashes.
