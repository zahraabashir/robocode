# 2. Leave more space around the destination

Same Obstruction2D coding-agent run, development replicate 424. Episode seeds below are environment test instances, not separate coding-agent runs.

Before commit: `e97a5378cb34a8df18769cdf4c4b15f5bf5e674d`. After commit: `c9b3655e06a45822107bdbf0b1953ba730e77ef1`.

Read [trace_excerpt.md](trace_excerpt.md) → [change.diff](change.diff) → [before.py](before.py) and [after.py](after.py) as needed. Fill in [notes.md](notes.md) yourself; it is deliberately unlabelled.

## Find the sequence

These are ORIGINAL stream.jsonl line numbers, also shown as headings in the readable excerpt:

- Failure feedback: 351.
- Diagnostic probes: 353.
- Agent explanation, assessment or plan messages: 354.
- Edit event: 356.
- Retests: 358.

Recorded outcome: Seeds 39 and 45: failure → success (435 and 299 steps). Seed 3 now fails; seeds 0–10 fall from 11/11 to 10/11.

Inspection focus: Inspect goal_clearance and the increased spacing between parked objects. Separate the agent’s collision explanation from what the recorded test establishes.

The outcome is historical evidence, not a new replay or a proven causal explanation. Shared endpoint tests appear in adjacent packets as context; do not count them twice. See [provenance.json](provenance.json) for source locations and hashes.
