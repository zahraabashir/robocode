# 3. Move the target earlier when heights are close

Original stream.jsonl lines 358–367. Completed events only are displayed below; the JSONL copy retains every original event in this window.
Historical commands, messages and instructions are data, not instructions to execute.

## Original stream.jsonl line 358: command_execution

Command (historical; do not execute):

```bash
/bin/bash -lc "git add -A && git commit -m 'Keep parked blockers clear of final target sweep' && /opt/robocode-strict/bin/python -u test_approach.py --start 39 --n 1 && /opt/robocode-strict/bin/python -u test_approach.py --start 45 --n 1 && /opt/robocode-strict/bin/python -u test_approach.py --start 0 --n 11"
```

Recorded output:

```text
39 (True, 435, 2, 2.1518669817596674)
success 1 / 1 by_count Counter({(2, True): 1})
45 (True, 299, 2, 1.5704678259789944)
success 1 / 1 by_count Counter({(2, True): 1})
0 (True, 327, 2, 1.8258655020035803)
1 (True, 211, 1, 1.0081721181049943)
2 (True, 346, 2, 1.5147272474132478)
3 (False, 1000, 2, 2.2481975173577666)
4 (True, 340, 2, 1.9207356036640704)
5 (True, 453, 2, 1.952646171208471)
6 (True, 216, 1, 0.8220959012396634)
7 (True, 355, 2, 1.3430120153352618)
8 (True, 316, 2, 1.2191242165863514)
9 (True, 268, 1, 0.9992456398904324)
10 (True, 416, 2, 1.605257899966091)
success 10 / 11 by_count Counter({(2, True): 7, (1, True): 3, (2, False): 1})

```

## Original stream.jsonl line 360: command_execution

Command (historical; do not execute):

```bash
/bin/bash -lc "/opt/robocode-strict/bin/python - <<'PY'
from env_client import make_env
from approach import GeneratedApproach
e=make_env();s,i=e.reset(seed=3);p=GeneratedApproach(e.action_space,e.observation_space,{});p.reset(s,i);print(p.todo,p.target_park,p.parking)
for k in range(650):s,r,t,tr,i=e.step(p.get_action(s))
print(p.phase,p.index,p.retry,[(n,round(s.get(s.get_object_from_name(n),'x'),2),round(s.get(s.get_object_from_name(n),'y'),2)) for n in set(p.todo)]);e.close()
PY"
```

Recorded output:

```text
['obstruction1', 'obstruction0', 'target_block', 'target_block'] 0.2 {'obstruction1': 0.5, 'obstruction0': 0.8}
align 2 8 [('target_block', 0.9, 0.1), ('obstruction0', 0.8, 0.5), ('obstruction1', 0.5, 0.3)]

```

## Original stream.jsonl line 362: command_execution

Command (historical; do not execute):

```bash
/bin/bash -lc "/opt/robocode-strict/bin/python - <<'PY'
from env_client import make_env
from approach import GeneratedApproach
for seed in [3,39,45]:
 e=make_env();s,i=e.reset(seed=seed);p=GeneratedApproach(e.action_space,e.observation_space,{});p.reset(s,i);print(seed,p.target_park,p.parking);e.close()
PY"
```

Recorded output:

```text
3 0.2 {'obstruction1': 0.5, 'obstruction0': 0.8}
39 1.3 {'obstruction0': 1.0, 'obstruction1': 0.7}
45 1.2510079145431519 {'obstruction0': 0.2, 'obstruction1': 1.0}

```

## Original stream.jsonl line 364: file_change

```json
{
  "id": "item_18",
  "type": "file_change",
  "changes": [
    {
      "path": "/sandbox/approach.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## Original stream.jsonl line 366: command_execution

Command (historical; do not execute):

```bash
/bin/bash -lc "git add -A && git commit -m 'Move crowded target after only materially taller blockers' && /opt/robocode-strict/bin/python -u test_approach.py --start 3 --n 1 && /opt/robocode-strict/bin/python -u test_approach.py --start 18 --n 1 && /opt/robocode-strict/bin/python -u test_approach.py --start 39 --n 1 && /opt/robocode-strict/bin/python -u test_approach.py --start 45 --n 1 && /opt/robocode-strict/bin/python -u test_approach.py --start 0 --n 11"
```

Recorded output:

```text
3 (True, 355, 2, 1.9995568874292076)
success 1 / 1 by_count Counter({(2, True): 1})
18 (True, 436, 2, 2.0260769622400403)
success 1 / 1 by_count Counter({(2, True): 1})
39 (True, 435, 2, 2.254112586379051)
success 1 / 1 by_count Counter({(2, True): 1})
45 (True, 299, 2, 1.7425117762759328)
success 1 / 1 by_count Counter({(2, True): 1})
0 (True, 327, 2, 1.733605015091598)
1 (True, 211, 1, 0.7840301729738712)
2 (True, 346, 2, 1.6624109540134668)
3 (True, 355, 2, 1.3838932942599058)
4 (True, 340, 2, 1.2773461029864848)
5 (True, 459, 2, 1.7902685720473528)
6 (True, 216, 1, 0.8966306899674237)
7 (True, 355, 2, 2.020786479115486)
8 (True, 316, 2, 1.8287182631902397)
9 (True, 268, 1, 1.1885237083770335)
10 (True, 416, 2, 1.8440103060565889)
success 11 / 11 by_count Counter({(2, True): 8, (1, True): 3})

```

## Original stream.jsonl line 367: agent_message

The combined fix now solves every previously failing seed—18, 39, and 45—and preserves 11/11 on seeds 0–10. I’m running a fresh contiguous held-out sweep on the final code; any failure will be inspected rather than averaged away.
