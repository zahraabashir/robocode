# 3. Move the target earlier when heights are close

Same Obstruction2D coding-agent run, development replicate 424. Episode seeds below are environment test instances, not separate coding-agent runs.

Before commit: `c9b3655e06a45822107bdbf0b1953ba730e77ef1`. After commit: `4d36a38a1864f8754cb3d3ed0c0bf114e1588e37`.

Read [trace_excerpt.md](trace_excerpt.md) → [change.diff](change.diff) → [before.py](before.py) and [after.py](after.py) as needed. Fill in [notes.md](notes.md) yourself; it is deliberately unlabelled.

## Find the sequence

These are ORIGINAL stream.jsonl line numbers, also shown as headings in the readable excerpt:

- Failure feedback: 358.
- Diagnostic probes: 360, 362.
- Agent explanation, assessment or plan messages: 367.
- Edit event: 364.
- Retests: 366.

Recorded outcome: Seed 3: failure → success at 355 steps. Seeds 18, 39 and 45 pass; seeds 0–10 return to 11/11.

Inspection focus: Inspect the 0.015 height threshold and target insertion into the task list. There is no separate pre-edit explanation message in this window; code comments and the commit title are evidence of stated intent, not full deliberation.

The outcome is historical evidence, not a new replay or a proven causal explanation. Shared endpoint tests appear in adjacent packets as context; do not count them twice. See [provenance.json](provenance.json) for source locations and hashes.
