# Five repair sequences to inspect

Start here. This is a small practice set from ONE Obstruction2D run: Codex GPT-5.6 Sol, strict blackbox, development replicate 424. You do not need to browse the full archive.

Selection rule: the already-studied seed-18 ordering repair (`e97a537`), followed by the next FOUR consecutive policy-changing commits. No commits between these five were skipped. This anchor was selected earlier for inspectability; the set is not a random sample or five independent experiments. It preserves regressions instead of selecting only successful repairs.

## Reading order

1. Skim [task.md](task.md) once: pick up the target block and place it on the designated surface, moving obstacles as needed.
2. Open one case folder below and read its `trace_excerpt.md` chronologically. If you want to practice without knowing the result in advance, stop at the edit event and write your interpretation before continuing to the retest.
3. Read `change.diff`; `-` lines were removed and `+` lines added. Use `before.py` and `after.py` for context.
4. Fill in that case's blank `notes.md`, keeping exact evidence references.
5. Continue to the next case only after you can explain the current change in one sentence.

Each case is one repair attempt, which can involve more than one test seed. These are attempts to repair problems; “repair” does not guarantee success everywhere.

## Five cases (outcome spoilers)

| Case | Original stream lines | Policy commits | Recorded result |
| --- | --- | --- | --- |
| [1. Change the order of moving objects](01_object_order/README.md) | 342–349 | `c1c4586 → e97a537` | Seed 18: failure at 1,000 steps → success at 436. Seeds 0–10 remain 11/11. |
| [2. Leave more space around the destination](02_parking_clearance/README.md) | 349–358 | `e97a537 → c9b3655` | Seeds 39 and 45: failure → success (435 and 299 steps). Seed 3 now fails; seeds 0–10 fall from 11/11 to 10/11. |
| [3. Move the target earlier when heights are close](03_target_timing/README.md) | 358–367 | `c9b3655 → 4d36a38` | Seed 3: failure → success at 355 steps. Seeds 18, 39 and 45 pass; seeds 0–10 return to 11/11. |
| [4. Avoid obstructing objects that still need to be picked up](04_future_pickups/README.md) | 367–380 | `4d36a38 → be6feb6` | Seeds 15 and 26: failure → success (447 and 403 steps). Seeds 0–10 pass, but the subsequent sweep shows seed 18 failing again. |
| [5. Refine ordering after seed 18 breaks again](05_overlap_exception/README.md) | 380–387 | `be6feb6 → 616a82f` | Seed 18: failure → success at 436 steps. Seed 15 and seeds 0–10 also pass. |

## Files and limits

- `trace_excerpt.md`: readable messages, commands and outputs, with original line references.
- `change.diff`: the exact saved policy edit.
- `before.py`, `after.py`: full policy source at the two commits; “before” does not mean first-ever code.
- `notes.md`: blank manual inspection worksheet, not a pre-labeled answer key.
- `trace_excerpt.jsonl`, `provenance.json`: exact raw excerpts, source path, commit IDs and hashes.
- Shared `test_approach.py`: byte-identical at all six boundary policy versions. Test output tuples mean `(terminated, steps, object_count, elapsed_seconds)`; the historical harness counts termination as success.
- Shared `config.yaml`: copied run settings, including budgets and evaluation configuration.

Case 1 overlaps the existing `actonomoy/obstruction2d_seed18` packet; it is the SAME example, not a new run. Some transcript windows overlap because one attempt's result is the next attempt's feedback. Distinguish cases from unique events when later counting labels. Cases 2 and 4 introduce recorded regressions; case 4 also changes two rules together.

No dataset-wide deduplication or population statistics are implied. All five cases share one development lineage. Related reruns and reevaluations should be grouped before any future cross-run aggregation. Archived messages (including claims about “held-out” tests) are evidence to check, not authoritative conclusions. These copies do not include complete internal reasoning.

No new robot rollouts were run and no formal taxonomy labeling was performed during extraction. These historical Python files are inspection copies, not a standalone executable package. The original dataset was not edited.

## Original source

Run directory:

```text
/Users/zahra.bashir/.cache/robocode-results-viewer/1sNuRoRxMxh7_VDE93hWn_ZNHBd74Uzt2/runs/Blackbox/Codex GPT5.6 Sol/kinematic2d/obstruction2d_generalized__agentic__none__blackbox__strict__codex_gpt56sol__timeout_60s__99b3a73f/2026-09-08_22-07-59/replicate_424
```

The main original sources were `stream.jsonl`, policy versions read from `sandbox/.git`, `sandbox/test_approach.py` at those versions, `env_description.md`, and `.hydra/config.yaml`. The final `sandbox/approach.py` and aggregate `results.json` describe later state/results, not these intermediate repairs.

Extraction script: `actonomoy/prepare_five_repair_sequences.py`. It only reads archive files and Git objects and writes this separate packet.
