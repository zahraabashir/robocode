# 4. Avoid obstructing objects that still need to be picked up

Same Obstruction2D coding-agent run, development replicate 424. Episode seeds below are environment test instances, not separate coding-agent runs.

Before commit: `4d36a38a1864f8754cb3d3ed0c0bf114e1588e37`. After commit: `be6feb60cb8cb0981cde9814194135d920128e75`.

Read [trace_excerpt.md](trace_excerpt.md) → [change.diff](change.diff) → [before.py](before.py) and [after.py](after.py) as needed. Fill in [notes.md](notes.md) yourself; it is deliberately unlabelled.

## Find the sequence

These are ORIGINAL stream.jsonl line numbers, also shown as headings in the readable excerpt:

- Failure feedback: 370.
- Diagnostic probes: 373.
- Agent explanation, assessment or plan messages: 367, 374.
- Edit event: 376.
- Retests: 378, 380.

Recorded outcome: Seeds 15 and 26: failure → success (447 and 403 steps). Seeds 0–10 pass, but the subsequent sweep shows seed 18 failing again.

Inspection focus: This commit combines TWO changes: height tolerance 0.015 → 0.035 and parking checks against future pickups. Do not attribute an outcome to either edit alone. The agent calls its sweep held-out, but it includes previously tested seeds such as 18 and 39.

The outcome is historical evidence, not a new replay or a proven causal explanation. Shared endpoint tests appear in adjacent packets as context; do not count them twice. See [provenance.json](provenance.json) for source locations and hashes.
